#pragma once

#include <cmath>
#include <map>
#include <vector>
#include <variant>

#include "RGB_t.h"

/// <summary>
/// A representetion of a single pixel in a scene. 
/// </summary>
struct pixel {
	/// <summary>
	/// Create a pixel in to be added to a scene
	/// </summary>
	/// <param name="pl">How the pixel is wired to the system</param>
	/// <param name="loc">TYhe location of the pixel in a cartesian 3D space, in millimeters</param>
	/// <param name="color"></param>
	pixel(uint8_t controller, uint8_t strip, uint16_t index, XYZ_t loc, RGB_t color = RGB_t(0, 0, 0)) :
		controller(controller), strip(strip), index(index), x((float)loc.x), y((float)loc.y), z((float)loc.z), color(color) {
		x_angle = atan2(z, y);
		y_angle = atan2(z, x);
		z_angle = atan2(y, x);
	}
	/// <summary>
	/// The ID of the controller for the pixel
	/// </summary>
	uint8_t controller;
	/// <summary>
	/// The strip number in the controller for the pixel
	/// </summary>
	uint8_t strip;
	/// <summary>
	/// The index of the pixel in its strip
	/// </summary>
	uint16_t index;

	/// <summary>
	/// The pixel's X coordinates in a millimeter based cartesian coordinates system
	/// </summary>
	float x;
	/// <summary>
	/// The pixel's Y coordinates in a millimeter based cartesian coordinates system
	/// </summary>
	float y;
	/// <summary>
	/// The pixel's Z coordinates in a millimeter based cartesian coordinates system
	/// </summary>
	float z;
	/// <summary>
	/// when looking at the model from left to right of the epoch, what is the angle of the pixel in degrees
	/// </summary>
	float x_angle;
	/// <summary>
	/// when looking at the model from front to back of the epoch, what is the angle of the pixel in degrees
	/// </summary>
	float y_angle;
	/// <summary>
	/// when looking at the model from top to bottom of the epoch, what is the angle of the pixel in degrees
	/// </summary>
	float z_angle;
	/// <summary>
	/// What is the color of the current pixel? Set this in a mode to change the display
	/// </summary>
	RGB_t color;
	/// <summary>
	/// The pixel's location as an XYZ_t
	/// </summary>
	/// <returns></returns>
	XYZ_t location() const { return { x,y,z }; }
};


/// <summary>
/// The bounds of a cube
/// </summary>
struct cube_bounds {
	double left, right, top, bottom, front, back;

	/// <summary>
	/// What the largest distance possible between two points in this cube
	/// </summary>
	/// <returns></returns>
	double max_distance();
	/// <summary>
	/// What is the max distance in this cube from the specified point
	/// </summary>
	/// <param name="epoch">Thepoint to measure the distance froem</param>
	/// <returns></returns>
	double max_distance_from(XYZ_t epoch);
	/// <summary>
	/// Is the specified poiont contained within the cube?
	/// </summary>
	/// <param name="point">the point to check</param>
	/// <returns></returns>
	bool contains(XYZ_t point);
};

/// <summary>
///  Describe a set of manipulations to be done on points/models
/// </summary>
struct transformation {
	enum class Type {
		Translate, Rotate, Scale, Mirror
	} type;
	XYZ_t values;
};

/// <summary>
/// Descibe a shape that can be drawn when 3D rendering the scene
/// </summary>
struct extra_shape {
	/// <summary>
	/// An external 3d model file, to be loaded and dispalyed
	/// </summary>
	struct extrnal_model {
		/// <summary>
		/// The path to the file to be loaded
		/// </summary>
		std::string path;
	};
	/// <summary>
	/// Describes a mesh to be drawn
	/// </summary>
	struct mesh {
		/// <summary>
		/// A list of all of the points in the mesh
		/// </summary>
		std::vector<XYZ_t> points;
		/// <summary>
		/// The paths of the poligons, describes in int3_vec of indexes to the points
		/// </summary>
		std::vector<int_vec3> paths;
	};

	/// <summary>
	/// The name of the object
	/// </summary>
	std::string name;
	/// <summary>
	/// The actual shape to be drawn
	/// </summary>
	std::variant<extrnal_model, mesh> data;
	/// <summary>
	/// List of the ways to transform the object
	/// </summary>
	std::vector<transformation> transformations;
	/// <summary>
	/// true to draw just the wireframe, false to draw facets
	/// </summary>
	bool wireframe{ false };
	/// <summary>
	/// The color in which to draw the shape, with an optional transperancy 
	/// </summary>
	RGBA_t color;
};


/// <summary>
/// Represents a part of a scene that can be rendered.
/// </summary>
class Zone {
public:
	/// <summary>
	/// The name of the zone
	/// </summary>
	std::string name;
	/// <summary>
	/// The pixels contained within the zone
	/// </summary>
	std::vector<pixel> pixels;
	//TODO: Doesn't belong here. Figure out another way. probably in mode. 
	/// <summary>
	/// The elements to be drawn added by the current mode.
	/// </summary>
	std::map<std::string, extra_shape> mode_elements;
	/// <summary>
	/// Get the cube containnig all the pixels in the current zone. The cube may contains pixels from other zones as well!
	/// </summary>
	/// <returns></returns>
	cube_bounds Bounds() const {
		if (pixels.empty()) return cube_bounds{ 0,0,0,0,0,0 };
		cube_bounds res = { pixels[0].x, pixels[0].x, pixels[0].z, pixels[0].z, pixels[0].y, pixels[0].y };
		for (const auto& p : pixels) {
			res.left = (std::min)((double)res.left, (double)p.x);
			res.right = (std::max)((double)res.right, (double)p.x);
			res.bottom = (std::min)((double)res.bottom, (double)p.z);
			res.top = (std::max)((double)res.top, (double)p.z);
			res.back = (std::min)((double)res.back, (double)p.y);
			res.front = (std::max)((double)res.front, (double)p.y);
		}

		return res;
	}
};