#pragma once

#include <cmath>
#include <map>
#include <vector>
#include <variant>

#include "RGB_t.h"

/// <summary>
/// This structs describes the phyhsical connection of pixel to a controller.
/// </summary>
struct pixel_connection {
	/// <summary>
	/// The ID of the controller
	/// </summary>
	uint16_t controller = 0xFFFF;
	/// <summary>
	/// The strip number for the pixel
	/// </summary>
	uint8_t strip = 0xFF;
	/// <summary>
	/// The index of the pixel on the strip
	/// </summary>
	uint16_t index = 0xFFFF;
};


struct pixel_metadata {
	XYZ_t location;
	pixel_connection connection;
	std::string tag;
};

struct pixel {
	pixel() : location({ 0,0,0 }) {}
	explicit pixel(const pixel_metadata& pm)  {
		this->location = pm.location;
		this->connection = pm.connection; 
		this->color = RGB_t(0);
	}
	XYZ_t location;
	pixel_connection connection;
	RGB_t color;
	double size_factor = 1.0;
};


/// <summary>
/// The bounds of a cube
/// </summary>
struct cube_bounds {
	double left, right, top, bottom, front, back;

	/// <summary>
	/// What the largest distance possible between two points in this cube
	/// </summary>
	/// <returns></returns>
	double max_distance() const;
	/// <summary>
	/// What is the max distance in this cube from the specified point
	/// </summary>
	/// <param name="epoch">Thepoint to measure the distance froem</param>
	/// <returns></returns>
	double max_distance_from(XYZ_t epoch) const;
	/// <summary>
	/// Is the specified poiont contained within the cube?
	/// </summary>
	/// <param name="point">the point to check</param>
	/// <returns></returns>
	bool contains(XYZ_t point) const;

	XYZ_t center() const;
};

/// <summary>
///  Describe a set of manipulations to be done on points/models
/// </summary>
struct transformation {
	enum class Type {
		Translate, Rotate, Scale, Mirror
	} type;
	XYZ_t values;
};

/// <summary>
/// Descibe a shape that can be drawn when 3D rendering the scene
/// </summary>
struct extra_shape {
	/// <summary>
	/// An external 3d model file, to be loaded and dispalyed
	/// </summary>
	struct extrnal_model {
		/// <summary>
		/// The path to the file to be loaded
		/// </summary>
		std::string path;
	};
	/// <summary>
	/// Describes a mesh to be drawn
	/// </summary>
	struct mesh {
		/// <summary>
		/// A list of all of the points in the mesh
		/// </summary>
		std::vector<XYZ_t> points;
		/// <summary>
		/// The paths of the poligons, describes in int3_vec of indexes to the points
		/// </summary>
		std::vector<int_vec3> paths;
	};

	/// <summary>
	/// The name of the object
	/// </summary>
	std::string name;
	/// <summary>
	/// The actual shape to be drawn
	/// </summary>
	std::variant<extrnal_model, mesh> data;
	/// <summary>
	/// List of the ways to transform the object
	/// </summary>
	std::vector<transformation> transformations;
	/// <summary>
	/// true to draw just the wireframe, false to draw facets
	/// </summary>
	bool wireframe{ false };
	/// <summary>
	/// The color in which to draw the shape, with an optional transperancy 
	/// </summary>
	RGBA_t color;
};
