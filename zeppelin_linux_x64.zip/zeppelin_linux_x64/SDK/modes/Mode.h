#pragma once

#include <string>
#include <vector>
#include <map>
#include <span>

#include "Zone.h"
#include "Parameters.h"
#include "ConfigNode.h"
#include "multispan.h"

using PixelSets = multispan<pixel>;

/// <summary>
/// Defines a 'Mode' - a piece of code capable of setting the color of each pixel at advancing timepoints. 
/// </summary>
class Mode :  protected ParametersController {
public:
	void Init(std::map<std::string, extra_shape>& mode_elements, ParametersController& params_controller, ConfigNode& config_node);
	/// <summary>
	/// The name of the mode. If RTTI is available, it defualts to the name of the class. 
	/// </summary>
	/// <returns>A string with the display name of the mode</returns>
	virtual std::string name() const;	
	/// <summary>
	/// A virtual destructor, does nothing in this base class
	/// </summary>
	virtual ~Mode() {}
	/// <summary>
	/// Called when the mode is initialized, with the current scene and zone that the mode will have to render. 
	/// </summary>
	/// <param name="scene">The whole scene that is being rendered, used for all parameters needed other than the pixels</param>
	/// <param name="zone">The zone rendered by this mode, where the actual pixels come from.</param>
	virtual void onEnter(PixelSets& pixels) {}
	/// <summary>
	/// Called when the mode is being destroyed
	/// </summary>
	virtual void onExit() {}
	/// <summary>
	/// Called for each frame. This function should change the color of the pixels in the Zone to set them.
	/// </summary>
	/// <param name="zone">The zone being rendered</param>
	/// <param name="time_ms">The timestamp, in ms, to which the frame corresponds.</param>
	virtual void onFrame(PixelSets& pixels, uint64_t time_ms) = 0;

	/// <summary>
	/// Get a vector of pointers to the parameters this mode exposes to modify its behavior. 
	/// It is recommended to make the parameters members, and return their address. If not
	/// otherwise set, parameters added here will join the "Mode" parameters group. 
	/// </summary>
	/// <returns>A vector of parameters poointers to the current mode's parametrs.</returns>
	virtual std::vector<Parameter*> GetModeParameters() = 0;

	static cube_bounds Bounds(const multispan<pixel>& pixels);

protected: 
	/// <summary>
	/// Return a color on the full saturation "Rainbow" spectrum. 
	/// It rotates back to the zero position every 768 indexes
	/// </summary>
	/// <param name="index"></param>
	/// <returns></returns>
	static RGB_t colorwheel(uint32_t index);

	void RefreshParameters() final {
		if (params_controller) {
			params_controller->RefreshParameters();
		}
	};
	
	std::map<std::string, extra_shape>* mode_elements = nullptr;
	ParametersController* params_controller = nullptr;
	ConfigNode* config_node = nullptr;
};

#ifdef WIN32
#define FUNCTION_EXPORT extern "C" __declspec(dllexport)
#else
#define FUNCTION_EXPORT extern "C"
#endif

#ifdef _MSC_VER
#define FUNCTION_CALL __cdecl
#else
#define FUNCTION_CALL
#endif
