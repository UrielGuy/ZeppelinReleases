#pragma once

template<typename T>
class range {
public:

    range(typename T::iterator first, typename T::iterator last) : first(first), last(last) {}
    range() :first(typename T::iterator{}), last(typename T::iterator{}) {}

    typename T::iterator begin() {
        return first;
    }

    typename T::iterator end() {
        return last;
    }

    const typename T::iterator begin() const{
        return first;
    }

    const typename T::iterator end() const {
        return last;
    }
private:
    typename T::iterator first;
    typename T::iterator last;
};