#pragma once

#include <vector>
#include <string>
#include <string_view>
#include <map>
#include <functional>
#include "RGB_t.h"
#include <variant>
#include <filesystem>
#include "ConfigNode.h"

#undef Bool

namespace YAML { class Node; }

struct CallDepthMeterGuard {
	CallDepthMeterGuard();
	~CallDepthMeterGuard();
};

//Added for the sequencer. This allows loggign and recording things to only rcord the top level change and not derived changes through callbacks.
class CallDepthMeter {
public:
	static int GetCallDepth();
	static void SetCallDepth(int depth);

private:
	CallDepthMeter() = delete;
};

class Parameter;

namespace Params {
	class ParameterBuilder;
}

struct TableData {

	friend class Params::ParameterBuilder;

	TableData(const std::vector<Parameter>& columns, const std::string& parent_path) : parent_path(parent_path), columns(columns) {};
	TableData(TableData&& other) = default;
	TableData& operator=(TableData&& other) = default;
	TableData(const TableData& other) = default;
	TableData& operator=(const TableData& other) = default; 

	struct CellChangedEvent {
		const Parameter& parameter;
		size_t row_id;
		size_t col_id;
	};

	struct RowDeletedEvent {
		std::vector<Parameter> row;
	};
	struct RowAddedEvent {
		size_t row_id;
		const std::vector<Parameter>& row;
	};

	struct RowsReordered {
		size_t src_row_id;
		const std::vector<Parameter>& src_row;
		size_t dst_row_id;
		const std::vector<Parameter>& dst_row;
	};

	using TableChangeEventArgs = std::variant<CellChangedEvent, RowDeletedEvent, RowAddedEvent, RowsReordered>;

	using TableNotifyDelegate = std::function<void(const TableChangeEventArgs& e)>;
	using CommandDelegate = std::function<void(const std::map<std::string, std::string>&)>;
	using ParameterValue = std::variant<int, double, std::string, RGB_t, bool, CommandDelegate, std::pair<int, int>, std::pair<double, double>, std::filesystem::path, TableData>;

	void RegisterForChange(const std::string& name, TableNotifyDelegate del) {
		delegates[name] = del;
	}
	void UnregisterForChange(const std::string& name) {
		delegates.erase(name);
	}

	void setValue(size_t row, size_t column, const ParameterValue& val, bool force_update = false);
	void setValue(size_t row, size_t column, const char* str, bool force_update = false) { setValue(row, column, std::string(str), force_update); }
	void setValue(size_t row, size_t column, const std::function<void()> del, bool force_update = false) { setValue(row, column, [=](const std::map<std::string, std::string>&) {del(); }, force_update); }
	void executeCommand(size_t row, size_t column, std::map<std::string, std::string> parameters);
	
	template<typename T>
	const T& as(size_t row, size_t column) const;

	Parameter& cell(size_t row, size_t column);
	const Parameter& cell(size_t row, size_t column) const {
		return values.at(row).at(column);
	}

	size_t row_count() { return values.size(); }
	void remove_row(size_t index);
	void clear_values() {
		values.clear();
		// TODO: Callback?
	}

	void swap_rows(size_t src_id, size_t dst_id) {
		std::swap(values[src_id], values[dst_id]);
		update_path();
		CallDepthMeterGuard depth_guard {};
		for (auto& del : delegates) { del.second(RowsReordered{ 
			.src_row_id = src_id,
			.src_row = values[src_id],
			.dst_row_id = dst_id,
			.dst_row = values[dst_id]
		}); }
	}

	const auto& get_columns() const {
		return columns;
	}

	std::vector<Parameter>& append_row();

	bool empty() { return row_count() == 0; }
	
	auto begin() { return values.begin(); }
	auto end() { return values.end(); }
	const auto begin() const { return values.cbegin(); }
	const auto end() const { return values.cend(); }
	
	friend bool operator==(const TableData& lhs, const TableData& rhs) {
		return
			lhs.allow_delete == rhs.allow_delete &&
			lhs.allow_reorder == rhs.allow_reorder &&
			lhs.min_items == rhs.min_items &&
			lhs.max_items == rhs.max_items &&
			lhs.columns == rhs.columns &&
			lhs.values == rhs.values;
	}


	bool allow_delete = false;
	bool allow_reorder = false;
	int min_items = 0;
	int max_items = std::numeric_limits<int>::max();

	int last_hovered = -1;

	void set_parent_path(std::string_view path) {
		parent_path = path;
		update_path();
	}

	
private:

	void update_path();
	std::string parent_path;

	std::map<std::string, TableNotifyDelegate> delegates;
	std::vector<Parameter> columns;
	std::vector<std::vector<Parameter>> values;


};

/// <summary>
/// Manages the value of runtime, user controlled value that affect the behavior of the program. Parameters
/// are colected from all aspects of the program (modes, extensions and built in) and are then controlled by
/// any UserInterface extension. 
/// Parameters have a data type, which is set using the "setValue" method, other than Command types that are
/// invoked by the "executeCommand" method. 
/// Additionally the can be associated with a certain group, such as "Mode", or "Diagnostics", etc. They can 
/// also be tagged as "NoAdmin", meaning they will be exposed to non admin users on UserInterfaces that
/// support that, such as the WebInterface.
/// Parameters should not be created directly. onstead they should be created by the helper methods in the 
/// Params namespace.
/// </summary>
class Parameter {
public:
	friend struct TableData;
	friend class Params::ParameterBuilder;
	/// <summary>
	/// A delegate type used to register for callbacks when a parameter is changes
	/// </summary>
	using NotifyDelegate = std::function<void(const Parameter&)>;

	using CommandDelegate = TableData::CommandDelegate;
	using ParameterValue = TableData::ParameterValue;

	/// <summary>
	/// A list of all of the types of parameters available. 
	/// </summary>
	enum class Type {
		/// <summary>
		/// A label, showing a piece of information to the user
		/// </summary>
		Label,
		/// <summary>
		/// An operation that can be invoked by the user.
		/// </summary>
		Command,
		/// <summary>
		/// A user controlled string value
		/// </summary>
		String,
		/// <summary>
		/// A user controlled integer value
		/// </summary>
		Integer,
		/// <summary>
		/// A user controlled floating point (actually a double) value
		/// </summary>
		Float,
		/// <summary>
		/// A user controlled RGB_t color
		/// </summary>
		Color,
		/// <summary>
		///  A user controlled boolean value
		/// </summary>
		Bool,
		/// <summary>
		/// A user controlled selection of a value out of a list of values. 
		/// </summary>
		Options,
		/// <summary>
		/// A table of multiple values,
		/// </summary>
		Table,
		FloatRange,
		IntRange,
		Path
	};

	/// <summary>
	/// The dispaly name of the parameter, showed by the UI
	/// </summary>
	std::string name;
	/// <summary>
	/// The dispaly group to associate this parameter with
	/// </summary>
	std::string group;

	/// <summary>
	/// The type of the parameter
	/// </summary>
	Type type;
	/// <summary>
	/// For Integer and Float typed parameters, this is the minimum value (included) that can be set.
	/// </summary>
	double range_min;
	/// <summary>
	/// For Integer and Float typed parameters, this is the maximum value (included) that can be set.
	/// </summary>
	double range_max;
	/// <summary>
	/// The list of values that an Options typed parameter can be set to
	/// </summary>
	std::vector<std::string> options;
	/// <summary>
	/// For a Command type, this is the list of the parameters supported by it. Command parameters can only be strings. 
	/// </summary>
	std::vector<std::string> command_parameters;

	std::vector<std::string> tags;

	/// <summary>
	/// Get the current value of the parameter
	/// </summary>
	/// <typeparam name="T">Either RGB_t, std::string, int or bool. Needs to match the type of the parameter</typeparam>
	/// <returns>The value of the parameter</returns>
	template<typename T>
	const T& as() const { return std::get<T>(value); }

	TableData& table() {
		if (type != Type::Table) throw std::runtime_error("This is not a table!");
		auto& res = std::get<TableData>(value);
		res.RegisterForChange("__lazy_param_own_table", [&](auto a) { 
			CallDepthMeterGuard depth_guard {};
			for (auto& item : delegates) item.second(*this);
		});
		return res;
	}

	const TableData& table() const {
		if (type != Type::Table) throw std::runtime_error("This is not a table!");
		return std::get<TableData>(value);
	}



	/// <summary>
	/// Sets the value of the current parameter.
	/// </summary>
	/// <param name="val">The value to set</param>
	/// <param name="force_update">If set to true, an update to the value and the update callback wiil be called
	/// even if the value being set is the same as the existing value.</param>
	void setValue(const ParameterValue& val, bool force_update = false);
	void setValue(const char* str, bool force_update = false) { setValue(std::string(str), force_update); }
	void setValue(const std::function<void()> del, bool force_update = false) { setValue([=](const std::map<std::string, std::string>&) {del(); }, force_update); }

	/// <summary>
	/// Registers for getting a notification when the parameter's value is changed.
	/// </summary>
	/// <param name="name">The name of the callback, must be unique per registration</param>
	/// <param name="del">The delegate to be invoked when the value changes</param>
	void RegisterForChange(const std::string& name, NotifyDelegate del);
	void UnregisterForChange(const std::string& name);
	/// <summary>
	/// Executes a command parameter
	/// </summary>
	/// <param name="parameters">The parameters needed to execute the command. The keys need to match the values of the command_parameters</param>
	void executeCommand(std::map<std::string, std::string> parameters);
	/// <summary>
	/// Return a tring representation of the current value
	/// </summary>
	/// <returns></returns>
	std::string to_string() const;
	/// <summary>
	/// Sets the current value with the correct type from a string representation.
	/// </summary>
	/// <param name="s"></param>
	void from_string(const std::string& s);

	bool HasTag(const std::string& tag) {
		return std::find(tags.begin(), tags.end(), tag) != std::end(tags);
	}

	void ClearRegistrations() { delegates.clear(); }

	std::string path() const {
		if (my_path.empty()) {
			if (group == "") my_path = name;
			else my_path = group + "." + name;
		}
		return my_path;
	}

	friend bool operator==(const Parameter& lhs, const Parameter& rhs) {
		return lhs.name == rhs.name && lhs.group == rhs.group;
	}

private:
	ParameterValue value;

	std::map<std::string, NotifyDelegate> delegates;
	
	mutable std::string my_path = "" ;
};

/// <summary>
/// Contains helper functions/types for creating parameters. 
/// </summary>
namespace Params {
	/// <summary>
	/// A helper class for creating parameters, don't create externally. 
	/// </summary>
	class ParameterBuilder : public Parameter {
	public:
		explicit ParameterBuilder(const std::string_view name);
		/// <summary>
		/// Associate the parameter being built with a specific group, such as "Diagnostics" of "Favorites"
		/// </summary>
		/// <param name="group">The name of the group to associate with</param>
		/// <returns>A reference to self, to allow for more calls</returns>
		ParameterBuilder& Group(const std::string_view group);
		/// <summary>
		/// Specifies this parameter doesn't require admin access to control on supporting UserInterfaces
		/// </summary>
		/// <returns>A reference to self, to allow for more calls</returns>
		ParameterBuilder& NoAdmin();
		ParameterBuilder& LocalUI();
		ParameterBuilder& SaveInFavorites();
		ParameterBuilder& VerboseSave();
		/// <summary>
		/// Register a callback to be invoked when the value of the parameter changes. 
		/// </summary>
		/// <param name="del">The delegate to be invoked, with the parameter changed as an argument</param>
		/// <returns></returns>
		ParameterBuilder& OnChange(NotifyDelegate del);
		/// <summary>
		/// Register a callback to be invoked when the value of the parameter changes. 
		/// </summary>
		/// <param name="del">The delegate to be invoked. The parameter can be accessed easily as a lambda capture.</param>
		/// <returns></returns>
		ParameterBuilder& OnChange(std::function<void(void)> del);
		ParameterBuilder& OnChange(std::function<void(size_t row, int col)> del);
			/// <summary>
		/// For Options parameter, invoke a callback when a specific value was set
		/// </summary>
		/// <param name="val">The value to check for</param>
		/// <param name="del">The delegate to be invoked </param>
		/// <returns></returns>
		ParameterBuilder& OnSelected(const std::string& val, NotifyDelegate del);
		/// <summary>
		/// For Options parameter, invoke a callback when a specific value was set
		/// </summary>
		/// <param name="val">The value to check for</param>
		/// <param name="callback">The delegate to be invoked </param>
		/// <returns></returns>
		ParameterBuilder& OnSelected(const std::string& val, std::function<void()> callback);
	};

	/// <summary>
	/// Create a "Command" parameter, which is usually a button on the UI
	/// </summary>
	/// <param name="name">The display name for the Parameter</param>
	/// <param name="command">The delegate that will be invoked when the command is executed</param>
	/// <param name="command_params">The list of parameters needed by the command.</param>
	/// <returns></returns>
	ParameterBuilder Button(const std::string& name, const Parameter::CommandDelegate& command, const std::vector<std::string> command_params = {});
	/// <summary>
	/// Create a "Command" parameter, which is usually a button on the UI. The overload doesn't have command parameters
	/// </summary>
	/// <param name="name">The display name for the Parameter</param>
	/// <param name="command">The delegate that will be invoked when the command is executed</param>
	/// <returns></returns>
	ParameterBuilder Button(const std::string& name, const std::function<void(void)>& command);
	/// <summary>
	/// Create a label - this just displays a piece of information and cannot be changed by the user. 
	/// </summary>
	/// <param name="name">The name of the laber</param>
	/// <returns></returns>
	ParameterBuilder Label(const std::string& name = "");
	/// <summary>
	/// Create a parameter with a boolean (true/false) value
	/// </summary>
	/// <param name="name">the name of the parameter</param>
	/// <param name="default_value">the initial value</param>
	/// <returns></returns>
	ParameterBuilder BoolVal(const std::string& name, bool default_value);
	/// <summary>
	/// Creates a parameter allowing the user to pick a color. 
	/// </summary>
	/// <param name="name">The name of the Parameter</param>
	/// <param name="default_value">The initial value</param>
	/// <returns></returns>
	ParameterBuilder Color(const std::string& name, RGB_t default_value);
	/// <summary>
	/// Ceate a parameter with a string value
	/// </summary>
	/// <param name="name">The name of the Parameter</param>
	/// <param name="default_value">The initial value</param>
	/// <returns></returns>
	ParameterBuilder StringVal(const std::string& name, const std::string& default_value);
	/// <summary>
	/// Create a Parameter controlling an integer value
	/// </summary>
	/// <param name="name">The name of the parameter</param>
	/// <param name="default_value">The initial value</param>
	/// <param name="min_val">The minimum value (inclusive) for the Parameter</param>
	/// <param name="max_val">The maximum value (inclusive) for the Parameter</param>
	/// <returns></returns>
	ParameterBuilder IntVal(const std::string& name, int default_value, int min_val, int max_val);
	/// <summary>
	/// Create a Parameter controlling a floating point (double) value
	/// </summary>
	/// <param name="name">The name of the parameter</param>
	/// <param name="default_value">The initial value</param>
	/// <param name="min_val">The minimum value (inclusive) for the Parameter</param>
	/// <param name="max_val">The maximum value (inclusive) for the Parameter</param>
	/// <returns></returns>
	ParameterBuilder FloatVal(const std::string& name, double default_value, double min_val, double max_val);
	/// <summary>
	/// Creates a Parameter for selecting a value out of a list of options. 
	/// </summary>
	/// <param name="name">The name of the parameter</param>
	/// <param name="options">The list of options to selet from. This can be modifed later from the "options" variable</param>
	/// <param name="default_value">The initial value</param>
	/// <returns></returns>
	ParameterBuilder Selection(const std::string& name, const std::vector<std::string>& options, const std::string& default_value);

	ParameterBuilder Table(std::string_view name, const std::vector<Parameter>& columns, bool allow_delete = false, bool allow_reorder = false, int min_items = 0);
	ParameterBuilder Path(std::string_view name, std::filesystem::path default_value, const std::vector<std::string_view>& filters);
	ParameterBuilder IntRange(std::string_view name, std::pair<int, int> default_value, int min, int max);
	ParameterBuilder FloatRange(std::string_view name, std::pair<double, double> default_value, double min, double max);

}

/// <summary>
/// This interface is used to notify the main program that the parameters has changed (different set of parameters are relevant, options for a 
/// Options parameter, etc.) and that we should refresh them. 
/// </summary>
class ParametersController {
public:
	/// <summary>
	/// Notify onparameters change and refresh all parameters throughout the program.
	/// </summary>
	virtual void RefreshParameters() = 0;
};


