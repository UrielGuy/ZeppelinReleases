#pragma once
#include <mutex>
#include <condition_variable>
#include <atomic>

/// <summary>
/// A minimal backport of C++23's std::barrier. 
/// </summary>
class barrier {
public:
    /// <summary>
    /// Initialize the barrier
    /// </summary>
    /// <param name="count">The amount of participants to wait for before releasing the barrier</param>
    explicit barrier(int count) : total(count) {}

    /// <summary>
    /// Wait for the set amount of participants to arrive at this point, them release all of them
    /// </summary>
    void await() {
        std::unique_lock<std::mutex> lock(mutex);
        if (++counter == total) {
            releasing = true;
            cond.notify_all();
        }
        else {
            cond.wait(lock, [this]() {return releasing == true; });
        }

        if (--counter == 0) releasing = false;
    }

    /// <summary>
    /// Release all the waiting participants right now.
    /// </summary>
    void stop() {
        releasing = true;
        cond.notify_all();
    }

private: 
    std::mutex mutex;
    std::condition_variable cond;
    std::atomic<bool> releasing { false };
    std::atomic<int> counter { 0 };
    int total;

    barrier(const barrier&) = delete;
    barrier& operator=(const barrier&) = delete;
};
