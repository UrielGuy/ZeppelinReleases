#pragma once
#include <functional>
#include <map>
#include <memory>
#include <deque>

class EventClient;

struct registration_holder {
    registration_holder() :deregister([] {}) {}
    explicit registration_holder(const std::function<void()>& deregistrator) : deregister(deregistrator) {}

    registration_holder(registration_holder&& other) = delete;
    
    registration_holder& operator=(registration_holder&& other) noexcept {
        deregister();
        deregister = other.deregister;
        other.deregister = [] {};
        return *this;
    }
  
    registration_holder(const registration_holder& other) = delete;
    registration_holder& operator=(const registration_holder& other) = delete;

    std::unique_ptr<registration_holder> as_ptr() {
        std::unique_ptr<registration_holder> res = std::make_unique<registration_holder>(deregister);
        deregister = [] {};
        return res;
    }

    ~registration_holder() {
        deregister();
    }

    void Release() {
        deregister();
        deregister = []() {};
    }
    std::function<void()> deregister;

    friend class EventClient;
};

uint64_t getLower64BitHashOfModuleName();
uint64_t getUniqueNumber();

class EventClient {
public:

    EventClient(EventClient&&) = delete;
    EventClient& operator=(EventClient&&) = delete;

    EventClient(const EventClient&) = delete;
    EventClient& operator=(const EventClient&) = delete;

    EventClient() {
        registration_id = getUniqueNumber();
    }

    void UnregisterAll() {
        holders.clear();
    }

    EventClient& operator+=(registration_holder&& other) {
        holders.emplace_back(other.deregister);
        other.deregister = ([] {});
        return *this;
    }
    template<typename... Args>
    friend class Event;
private:
    uint64_t registration_id;
    std::deque<registration_holder> holders;

private:
        
};

template <typename... Args>
class Event {
    using delegate = std::function<void(Args...)>;
   
    struct data_t {
        std::map<uint64_t, delegate> registrations;
    };

    std::shared_ptr<data_t> data = std::make_shared<data_t>();


public:
    Event() {};
    Event(Event&&) = default;
    Event& operator=(Event&&) = default;

    Event(const Event& other) : Event() {};
    Event& operator=(const Event&) {
        data = std::make_shared<data_t>();
        return *this;
    }
   
    [[nodiscard]]
    registration_holder Register(const delegate& func) {
        uint64_t registration = getUniqueNumber();
        data->registrations[registration] = func;
        return  registration_holder(
            [data_weak = std::weak_ptr(data), registration]() {
                auto locked = data_weak.lock();
                if (locked) {
                    locked->registrations.erase(registration);
                }
            }
        );
    }

    // Only use when you are sure the delegate will not move, and will have alonger lifetime than the event.
    void RegisterForever(const delegate& func) {
        uint64_t registration = getUniqueNumber();
        data->registrations[registration] = func;
    }

    void Invoke(Args... args) {
        for (auto& item : data->registrations) {
            item.second(args...);
        }
    }

    void operator()(Args... args) {
        Invoke(args...);
    }
};