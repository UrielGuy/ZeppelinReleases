#pragma once
#include <functional>
#include <string>
#include <vector>
#include <shared_mutex>
#include <span>
#include <algorithm> 

#include "libmodes/Parameters.h"
#include "libmodes/ConfigNode.h"
#include "libmodes/Zone.h"
#include "libmodes/multispan.h"
#include "ParameterNode.h"

#undef MessageBox

std::string GetCurrentModuleName();

/// <summary>
/// A UserInterface is an extension interface meant to manipulate parameters
/// </summary>
class UserInterface {
public:
	enum MessageButton : uint32_t {
		None = 0,
		Yes = 1 << 1,
		No = 1 << 2,
		Retry = 1 << 3,
		Cancel = 1 << 4,
		OK = 1 << 5,
		DontAskAgain = 1 << 6
	};

	struct MessageBoxData {
		std::string caption;
		std::string message;
		MessageButton buttons;
		std::function<void(MessageButton)> callback;
		MessageButton default_value;
	};
	/// <summary>
	/// This is called to notify the UserInterface that the set of Parameters has changed. 
	/// </summary>
	/// <param name="parameters">The root of the Parameters tree</param>
	virtual void UpdateParameters(const ParametersNode& parameters) = 0;

	/// <summary>
	/// Returns weather the Messagebox was actually showed to the user.
	/// </summary>
	/// <param name="data"></param>
	/// <returns></returns>
	virtual bool MessageBox(const MessageBoxData& data) = 0;
};

/// <summary>
/// This interface allows queueing an action to happen at the begining of the next frame, when no other operations are in flight.
/// </summary>
class ZeppelinAppCallbacks : public ParametersController {
public:
	/// <summary>
	/// Enqueue an action to happen at the begning of the next frame
	/// </summary>
	/// <param name="item">A delegate to be executed at the start of the next frame</param>
	virtual void EnqueueAction(std::function<void()> item) = 0;

	virtual void MessageBox(const std::string& caption, const std::string& message, UserInterface::MessageButton buttons, std::function<void(UserInterface::MessageButton)> callback, UserInterface::MessageButton default_button) = 0;
	ConfigNode& GetAppConfig() {
		return GetAppConfig(GetCurrentModuleName());
	}
protected:
	virtual ConfigNode& GetAppConfig(std::string_view component) = 0;
};

/// <summary>
/// A FrameConsumer is an extension interface to handle a frame once it's built. Some uses for this are the 3D renderer, 
/// or drivers for various controllers. 
/// </summary>
class FrameConsumer {
public:
	/// <summary>
	/// Get the name of the controller., defaulting to the class name
	/// </summary>
	/// <returns></returns>
	virtual std::string name() const { return typeid(*this).name() + 6; }
	/// <summary>
	/// A function to be called every time a frame is ready for processing. 
	/// </summary>
	/// <param name="scene"></param>
	/// <param name="timestamp">The timestamp for which the frame was generated. </param>
	virtual void onFrame(uint64_t timestamp, const multispan<pixel>& pixels, std::vector<std::map<std::string, extra_shape>*> mode_elements) = 0;
	/// <summary>
	/// A function to be called every time the zones being consumed are changed.
	/// </summary>
	/// <param name="scene"></param>
	/// <param name="timestamp">The timestamp for which the frame was generated. </param>
	virtual void onZonesChanged(const multispan<pixel>& pixels) = 0;

	virtual void OnModeChange(const std::string& zone_name) = 0;
	/// <summary>
	/// A call to get the Parameters controlling the FrameConsumer.
	/// </summary>
	/// <returns>A vector of pointers to the parameters exposed by the FramesConsumer</returns>
	virtual std::vector<Parameter*> GetConsumerParameters() = 0;
};

class Mather;

class PixelsProvider {
public: 
	virtual std::string GetName() const {
		std::string name = typeid(*this).name();
		if (name.size() >= 6 && name.substr(0, 6) == "class ") {
			name = name.substr(6);
		}
		while (isdigit(name[0])) {
			name = name.substr(1);
		}
		return name;
	};
	virtual std::vector<std::string> GetAvailableZoneDivisons() = 0;
	virtual std::map<std::string, std::span<pixel>> GetPixels(const std::string& zone_division_name) = 0;
	virtual void UpdatePixles(uint64_t timestamp_ms) = 0;
	virtual std::vector<Parameter*> GetParameters() = 0;
	
	void RegisterForPixelsUpdate(std::function<void()> callback) { callbacks.push_back(callback); }
protected:
	void NotifyPixelsUpdated() {
		std::ranges::for_each(callbacks, [](auto& callback) { callback(); });
	}
private:
	std::vector<std::function<void()>> callbacks;
};


class TickGenerator {
public: 
	virtual void StartTicks() = 0;
	virtual bool WaitForNextTick() = 0;
	virtual void StopTicks() = 0;
};

struct ExtensionInitParams {
	const std::string* configuration;
	Mather* mather;
	std::shared_timed_mutex* parameters_mutex;
	ZeppelinAppCallbacks* app_callbacks;
	ConfigNode* config_node;
};

struct ExtensionUpdateParams {
	const std::string* configuration;
	Mather* mather;
	ConfigNode* config_node;
};


#ifdef WIN32
#define FUNCTION_EXPORT extern "C" __declspec(dllexport)
#else
#define FUNCTION_EXPORT extern "C"
#endif

#ifdef _MSC_VER
#define FUNCTION_CALL __cdecl
#else
#define FUNCTION_CALL
#endif

