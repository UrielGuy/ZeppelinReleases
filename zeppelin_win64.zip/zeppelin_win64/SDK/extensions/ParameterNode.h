#pragma once

#include <string>
#include <vector>
#include <map>
#include <memory>
#include <libmodes/Parameters.h>


/// <summary>
/// This describes a node in the Parameter tree - starting with a root and contaiing groups of parameters. 
/// </summary>
struct ParametersNode {
	/// <summary>
	///  Thename of the current node
	/// </summary>
	std::string name;
	/// <summary>
	/// A vector with all of the parameters in the current node
	/// </summary>
	std::vector<Parameter*> params;
	/// <summary>
	/// A map with the name as the key and the parameters 
	/// </summary>
	std::map<std::string, std::shared_ptr<ParametersNode>> sub_nodes;
	bool parameters_before_sub_nodes = true;
	ParametersNode& operator[](const std::string& name);

	std::string toJsonString(bool is_admin, bool local_ui) const;
};

