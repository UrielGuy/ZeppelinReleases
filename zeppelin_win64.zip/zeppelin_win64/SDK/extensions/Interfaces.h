#pragma once
#include <functional>
#include <string>
#include <vector>
#include "libmodes/Parameters.h"
#include "libmodes/ConfigNode.h"
#include "libmodes/Zone.h"
#include "ParameterNode.h"

/// <summary>
/// Represents a set of complementing zones.
/// This is a collection of zones,. where every pixel is contained in exacly one zone
/// </summary>
class ZoneDivision {
public:
	/// <summary>
	///  The name of this setup 
	/// </summary>
	std::string name;
	/// <summary>
	/// The list of zones in this devision;
	/// </summary>
	std::vector<Zone> zones;

	/// <summary>
	/// Gets a cube conatining all the pixels in all the zones in this division.
	/// </summary>
	/// <returns></returns>
	cube_bounds Bounds() const {
		cube_bounds res = zones.begin()->Bounds();
		for (const auto& item : zones) {
			auto other = item.Bounds();
			res.left = (std::min)(res.left, other.left);
			res.right = (std::max)(res.right, other.right);
			res.bottom = (std::min)(res.bottom, other.bottom);
			res.top = (std::max)(res.top, other.top);
			res.back = (std::min)(res.back, other.back);
			res.front = (std::max)(res.front, other.front);
		}
		return res;
	}

};

/// <summary>
/// This interface allows queueing an action to happen at the begining of the next frame, when no other operations are in flight.
/// </summary>
class FrameThreadInvoker {
public:
	/// <summary>
	/// Enqueue an action to happen at the begning of the next frame
	/// </summary>
	/// <param name="item">A delegate to be executed at the start of the next frame</param>
	virtual void EnqueueItem(std::function<void()> item) = 0;
};

/// <summary>
/// Start generating callbacks for frame generation.
/// Unless writing a new renderer, you probably don't need this. 
/// </summary>
class TickGenerator {
public:
	virtual void StartTicks(std::function<void(uint64_t)> callback) = 0;
	virtual std::vector<Parameter*> GetTickerParameters() = 0;
};

/// <summary>
/// A FrameConsumer is an extension interface to handle a frame once it's built. Some uses for this are the 3D renderer, 
/// or drivers for various controllers. 
/// </summary>
class FrameConsumer {
public:
	/// <summary>
	/// Get the name of the controller., defaulting to the class name
	/// </summary>
	/// <returns></returns>
	virtual std::string name() const { return typeid(*this).name() + 6; }
	/// <summary>
	/// A function to be called every time a frame is ready for processing. 
	/// </summary>
	/// <param name="scene"></param>
	/// <param name="timestamp">The timestamp for which the frame was generated. </param>
	virtual void onFrame(const ZoneDivision& zones, uint64_t timestamp) = 0;
	/// <summary>
	/// A function to be called every time the zones being consumed are changed.
	/// </summary>
	/// <param name="scene"></param>
	/// <param name="timestamp">The timestamp for which the frame was generated. </param>
	virtual void onZonesChanged(const ZoneDivision& zones) = 0;
	/// <summary>
	/// A call to get the Parameters controlling the FrameConsumer.
	/// </summary>
	/// <returns>A vector of pointers to the parameters exposed by the FramesConsumer</returns>
	virtual std::vector<Parameter*> GetConsumerParameters() = 0;
};

/// <summary>
/// A UserInterface is an extension interface meant to manipulate parameters
/// </summary>
class UserInterface {
public:
	/// <summary>
	/// This is called to notify the UserInterface that the set of Parameters has changed. 
	/// </summary>
	/// <param name="parameters">The root of the Parameters tree</param>
	virtual void UpdateParameters(const ParametersNode& parameters) = 0;
};


#ifdef WIN32
#define FUNCTION_EXPORT extern "C" __declspec(dllexport)
#else
#define FUNCTION_EXPORT extern "C"
#endif

#ifdef _MSC_VER
#define FUNCTION_CALL __cdecl
#else
#define FUNCTION_CALL
#endif

