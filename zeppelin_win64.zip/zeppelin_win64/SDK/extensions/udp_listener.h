#pragma once

#ifdef _WIN32
#include <winsock2.h>
#else
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <arpa/inet.h>
#include <unistd.h>
#endif
#include <thread>
#include <cstring>
#include <iostream>
#include <string>
#include <array>
#include <functional>
#include "logger.h"

std::string ip_to_str(uint32_t addr);

enum class controller_type : uint16_t {
    easypixel_v2 = 1,
    wifizep_v1 = 2,
    touchy_blinky_v5 = 3,
};

template<>
struct fmt::formatter<controller_type> : fmt::formatter<std::string>
{
    auto format(controller_type my, format_context& ctx) -> decltype(ctx.out())
    {
        switch (my) {
		case controller_type::easypixel_v2: return fmt::format_to(ctx.out(), "EasyPixel V2.2");
        case controller_type::wifizep_v1: return  fmt::format_to(ctx.out(), "WiFiZep V1.0");
        case controller_type::touchy_blinky_v5: return  fmt::format_to(ctx.out(), "TouchyBlinky V5.0");
        default: return  fmt::format_to(ctx.out(), "Unknown value: {}", (uint16_t)my);
        }

    }
};

enum class ControllerState {
    Online,
    Offline
};

template<>
struct fmt::formatter<ControllerState> : fmt::formatter<std::string>
{
    auto format(ControllerState my, format_context& ctx) -> decltype(ctx.out())
    {
        switch (my) {
		case ControllerState::Online: return fmt::format_to(ctx.out(), "Online");
		case ControllerState::Offline: return  fmt::format_to(ctx.out(), "Offline");
		default: return  fmt::format_to(ctx.out(), "Unknown value: {}", (uint16_t)my);
        }

    }
};

// This class sends a reset UDP on initializtion. 
// It then creates a thread listening for "Announce" UDP packets, containing the 
// controller's ID and IP address. 
// To query the listener one can call the GetIP() method. it takes the ID of a 
// controller, and returns the IP if one was read in the last 5 seconds. Otherwise
// 0 is returned. 
class Listener {
public:
    Listener(uint16_t port, controller_type type);
    ~Listener();

    void stop(); 

    void NotifyDown(uint16_t id);
    using ListenerCallback = std::function<void(uint16_t id, ControllerState state , uint32_t ip)>;
    void RegisterForClientNotifications(uint16_t id, ListenerCallback callback) {
        data[id].callback = callback;
    }

private:
    controller_type type;
    bool stopped = false;
    void listen(uint16_t port);
    
    struct controller_data {
        uint32_t ip = 0;
        time_t timestamp = 0;
        ListenerCallback callback = [](uint16_t, ControllerState, uint32_t) {};
        ControllerState last_state = ControllerState::Offline;
    };

    std::array<controller_data, 64 * 1024> data;

    std::thread listen_thread;


#ifdef _WIN32
    SOCKET fd;
#else
    int fd;
#endif

};
