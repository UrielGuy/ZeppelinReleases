#pragma once

#include <span>
#include <vector>

template <typename T>
class multispan {
public:
    multispan() {};

    multispan(std::initializer_list<std::span<T>> il) {
        std::copy(il.begin(), il.end(), std::back_inserter(data));
    }

    void add_span(std::span<T>& new_span) {
        if (new_span.empty()) return;
        data.push_back(new_span);
    }

    void clear() {
        data.clear();
    }
    bool empty() const {
        if (data.empty()) return true;
        for (const auto& span : data) {
            if (!span.empty()) return false;
        }
        return true;
    }

    size_t size() const {
        size_t res = 0;
        for (const auto& s : data) res += s.size();
        return res;
    }
    friend class Iterator;

    struct Iterator {
        Iterator() :owner(nullptr), span_index(0), cur_span(nullptr) , end_span_index(0) {}
        Iterator(const multispan<T>* owner, size_t span_index, std::span<T>::iterator it) :
            owner(owner), span_index(span_index), cur_span(&owner->data[span_index]), cur_it(it), end_span_index(owner->data.size() - 1)  {}

        // This is a lie, but needed to be able to build a span on top of multispan.
        using iterator_category = std::contiguous_iterator_tag;
        using difference_type = std::ptrdiff_t;
        using value_type = T;
        using pointer = T*;
        using reference = T&;

        reference operator*() const { return *cur_it; }
        pointer operator->() {
            return &(*cur_it);
        }

        Iterator& operator++() {
            cur_it++;
            while (span_index != end_span_index && cur_it == cur_span->end()) {
                span_index++;
                cur_span = &owner->data[span_index];
                cur_it = cur_span->begin();
            }
            return *this;
        }
        Iterator operator++(int) { Iterator tmp = *this; ++(*this); return tmp; }

        Iterator& operator+=(difference_type diff) {
            *this = *this + diff;
        }

        Iterator& operator--() {
            while (cur_it == cur_span->begin() && span_index != 0) {
                span_index--;
                cur_span = &owner->data[span_index];
                cur_it = cur_span->end();
            }
            cur_it--;
            return *this;
        }
        Iterator operator--(int) { Iterator tmp = *this; --(*this); return tmp; }
        Iterator& operator-=(difference_type diff) {
            *this = *this - diff;
        }

        friend Iterator operator+(const Iterator& it, difference_type diff) {
            Iterator copy = it;
            while (true) {
                ptrdiff_t available = std::distance(copy.cur_it, copy.cur_span->end());
                if (available > diff) {
                    copy.cur_it += diff;
                    return copy;
                }
                else {
                    diff -= available;
                    copy.span_index++;
                    copy.cur_span = &copy.owner->data[copy.span_index];
                    copy.cur_it = copy.cur_span->begin();
                }
            }
            return copy;
        }
        friend Iterator operator+(difference_type diff, const Iterator& it) {
            return it + diff;
        }

        friend Iterator operator-(const Iterator& it, difference_type diff) {
            Iterator copy = it;
            while (true) {
                size_t available = std::distance(copy.cur_span->begin(), copy.cur_it);
                if (available >= diff) {
                    copy.cur_it -= diff;
                    return copy;
                }
                else {
                    diff -= available;
                    copy.span_index--;
                    copy.cur_span = &copy.owner->data[copy.span_index];
                    copy.cur_it = copy.cur_span->end();
                }
            }
            return copy;
        }
        friend Iterator operator-(difference_type diff, const Iterator& it) {
            return it - diff;
        }

        friend bool operator== (const Iterator& a, const Iterator& b) {
            return
                a.owner == b.owner &&
                a.cur_span == b.cur_span &&
                a.cur_it == b.cur_it;
        };
        friend bool operator!= (const Iterator& a, const Iterator& b) { return !(a == b); };

        friend auto operator <=>(const Iterator& a, const Iterator& b) noexcept {
            if (a.span_index == b.span_index) {
                return a.cur_it <=> b.cur_it;
            }
            return a.span_index <=> b.span_index;
        }

        friend ptrdiff_t operator -(const Iterator& a, const Iterator& b) noexcept {
            if (a == b) return 0;
            if (b > a) return -(b - a);
            ptrdiff_t dist = 0;
            auto c = b;
            while (a.span_index != c.span_index) {
                dist += std::distance(c.cur_span->begin(), c.cur_it);
                c.span_index--;
                c.cur_span = &c.owner->data[c.span_index];
                c.cur_it = c.cur_span->end();
            }

            return dist + std::distance(c.cur_it, a.cur_it);
        }

    private:
        const multispan<T>* owner;
        size_t  span_index;
        size_t end_span_index;
        const std::span<T>* cur_span;
        std::span<T>::iterator cur_it;

        //static_assert(std::contiguous_iterator<Iterator>);
    };

    using iterator = Iterator;

    iterator begin() {
        if (data.empty()) return iterator{};
        return iterator(this, 0, data.front().begin());
    }
    iterator begin() const {
        if (data.empty()) return iterator{};
        return iterator(this, 0, data.front().begin());
    }

    iterator end() {
        if (data.empty()) return iterator{};
        return iterator(this, data.size() - 1, data.back().end());
    }
    iterator end() const {
        if (data.empty()) return iterator{};
        return iterator(this, data.size() - 1, data.back().end());
    }

    std::vector<std::span<T>> data;
};