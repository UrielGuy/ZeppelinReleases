#pragma once
#include <vector>

#include "Mode.h"

class XYMode : public Mode {
public:
	virtual void onEnter(PixelSets& pixels) override;
	void onFrame(PixelSets& pixels, uint64_t time_ms) final;
	std::vector<Parameter*> GetModeParameters() final;

	
protected:
	struct XYPixel {
		uint32_t x;
		uint32_t y;
		RGB_t color;
		std::vector<pixel*> leds;
	};
	
	
	
	int width = 30;
	int height = 30;
	XYZ_t center = { 0,0,0 };
	XYZ_t rotation = { 0,0,0 } ;
	bool x_use_angle = true;
	bool y_use_angle = true;
	double x_total_width = 3000;
	double x_total_angle = 90;
	double y_total_height = 3000;
	double y_total_angle = 90;

	RGB_t outside_color = { 0,0,0 };
	cube_bounds bounds = { 0,0,0,0,0,0 };
	double max_distance = 0;
	using XYFrame = std::vector<std::vector<XYPixel>>;
	virtual void onXYFrame(XYFrame& frame, uint64_t time_ms) = 0;
	virtual std::vector<Parameter*> GetXYModeParameters() = 0;

	void ParametersUpdated();


protected:
	XYFrame xy_pixels;
	extra_shape mesh;

	void ChangeSetup(const std::string& new_setup);

	PixelSets* pixels = nullptr;
	
protected: 
	Parameter setup = Params::Selection("XYSetup", {}, "" ).OnChange([this]() {ChangeSetup(setup.as<std::string>()); });
	Parameter show_projection = Params::BoolVal("Show Projection", true);
	Parameter projection_length = Params::IntVal("Projection length", 3000, 1, 30000);
};

class XYSetup : public XYMode {
public: 
	XYSetup();
protected:
	virtual void onEnter(PixelSets& pixels) override;
	void onXYFrame(XYFrame& frame, uint64_t time_ms) override;
	std::vector<Parameter*> GetXYModeParameters() override;

private:

	void SaveSettings(const std::string& name);

	Parameter p_width = Params::IntVal("Width", 30, 0, 1000).OnChange([this](const Parameter& p) { width = p.as<int>();  ParametersUpdated();  }).Group("${mode}.XY Setup");
	Parameter p_height = Params::IntVal("Height", 30, 0, 1000).OnChange([this](const Parameter& p) { height = p.as<int>(); ParametersUpdated();  }).Group("${mode}.XY Setup");
	Parameter p_center_x = Params::FloatVal("Center X", 0, -10000, 10000).OnChange([this](const Parameter& p) { center.x = p.as<double>(); ParametersUpdated(); }).Group("${mode}.XY Setup");
	Parameter p_center_y = Params::FloatVal("Center Y", 0, -10000, 10000).OnChange([this](const Parameter& p) { center.y = p.as<double>(); ParametersUpdated(); }).Group("${mode}.XY Setup");
	Parameter p_center_z = Params::FloatVal("Center Z", 0, -10000, 10000).OnChange([this](const Parameter& p) { center.z = p.as<double>(); ParametersUpdated(); }).Group("${mode}.XY Setup");
	Parameter p_rotation_x = Params::FloatVal("Rotation X", 0, -360, 360).OnChange([this](const Parameter& p) { rotation.x = p.as<double>(); ParametersUpdated(); }).Group("${mode}.XY Setup");
	Parameter p_rotation_y = Params::FloatVal("Rotation Y", 0, -360, 360).OnChange([this](const Parameter& p) { rotation.y = p.as<double>(); ParametersUpdated(); }).Group("${mode}.XY Setup");
	Parameter p_rotation_z = Params::FloatVal("Rotation Z", 0, -360, 360).OnChange([this](const Parameter& p) { rotation.z = p.as<double>(); ParametersUpdated(); }).Group("${mode}.XY Setup");
	Parameter p_x_use_angle = Params::BoolVal("X Use Angle", true).OnChange([this](const Parameter& p) { x_use_angle = p.as<bool>(); ParametersUpdated(); RefreshParameters(); }).Group("${mode}.XY Setup");
	Parameter p_x_total_angle = Params::IntVal("X total angle", 90, 1, 360).OnChange([this](const Parameter& p) { x_total_angle = p.as<int>(); ParametersUpdated(); }).Group("${mode}.XY Setup");
	Parameter p_x_total_width = Params::IntVal("X total width", 3000, 10, 10000).OnChange([this](const Parameter& p) { x_total_width = p.as<int>(); ParametersUpdated(); }).Group("${mode}.XY Setup");
	Parameter p_y_use_angle = Params::BoolVal("Y Use Angle", true).OnChange([this](const Parameter& p) { y_use_angle = p.as<bool>(); ParametersUpdated(); RefreshParameters(); }).Group("${mode}.XY Setup");
	Parameter p_y_total_angle = Params::IntVal("Y total angle", 90, 1, 360).OnChange([this](const Parameter& p) { y_total_angle = p.as<int>(); ParametersUpdated(); }).Group("${mode}.XY Setup");
	Parameter p_y_total_height = Params::IntVal("y total height", 3000, 10, 10000).OnChange([this](const Parameter& p) { y_total_height = p.as<int>(); ParametersUpdated(); }).Group("${mode}.XY Setup");
	Parameter save = Params::Button(
		"Update XY Setup",
		[this](std::map<std::string, std::string> params) {SaveSettings(params.at("Name")); RefreshParameters(); },
		{ "Name" }).Group("${mode}.XY Setup");

};


