#pragma once
#include <thread>
#include <mutex>
#include <future>
#include <deque>
#include <span>

#include "Mode.h"
#include "barrier.h"
#include "range.h"


/// <summary>
///  This mode is a base class for CPU intensive modes. For every frame, it will call an init and a finish function on the main thread, and then
/// will call the 'onFrameRange' function in a thread per CPU core, with a begin and end iterator range for the pixels to be set in that thread.
/// </summary>
class MultiThreadedMode : public Mode {
protected:
	/// <summary>
	/// A rename for the iterator used to pass the pixel range for each mode.
	/// </summary>
	using thread_pixels = range<PixelSets>;
public:
	/// <summary>
	/// Initialize a multi threaded mode, runing on 'thread_count' threads
	/// </summary>
	/// <param name="thread_count">The amount of threads to use. Defaults to all cores on the current machine.</param>
	MultiThreadedMode(uint32_t thread_count = std::thread::hardware_concurrency()) 
		: start_frame(thread_count), frame_ready(thread_count), thread_count(thread_count)	{}

	/// <summary>
	/// Initializes the threads. If you need to implement this for a multi threaded mode, override 'onModeEnter'. 
	/// </summary>
	/// <param name="scene"></param>
	/// <param name="zone"></param>
	void onEnter(PixelSets& pixels) final {
		onModeEnter(pixels);
		auto total_pixels = 0;
		unsigned i = 0;
		for (; i < thread_count - 1; i++) {
			
			size_t offset = pixels.size() / thread_count;
			thread_pixels tp (
				pixels.begin() + i * offset,
				pixels.begin() + (i + 1) * offset
			);

			threads.emplace_back([this, tp]() {
				while (!stop) {
					start_frame.await();
					if (stop) return;

					onFrameRange(tp, cur_time_ms);

					frame_ready.await();
				}
			});
		}
		size_t offset = pixels.size() / thread_count;

		main_thread_pixels = thread_pixels(
			pixels.begin() + i * offset,
			pixels.end()
		);
	}

	/// <summary>
	/// Terminated all the threads. if you need this functionallity, override 'onModeExit'. 
	/// </summary>
	void onExit() final {
		stop = true;
		start_frame.stop();
		frame_ready.stop();
		for (auto& td : threads) {
			td.join();
		}
		onModeExit();
	}
	
	/// <summary>
	/// Internal implementation for ofFrame. Not needed by external developers. 
	/// </summary>
	/// <param name="zone"></param>
	/// <param name="time_ms"></param>
	void onFrame(PixelSets& pixels, uint64_t time_ms) final {
		onFrameStart(time_ms);

		cur_time_ms = time_ms;
		start_frame.await();
		onFrameRange(main_thread_pixels, time_ms);
		frame_ready.await();

		onFrameEnd(time_ms);
	}

	/// <summary>
	/// Get a vector of pointers to the parameters this mode exposes to modify its behavior. 
	/// It is recommended to make the parameters members, and return tehir address. 
	/// </summary>
	/// <returns>A vector of parameters poointers to the current mode's parametrs.</returns>
	virtual std::vector<Parameter*> GetModeParameters() = 0;

protected: 
	/// <summary>
	/// Called when the mode is initialized, same as Mode's onEnter
	/// </summary>
	/// <param name="scene"></param>
	/// <param name="zone"></param>
	virtual void onModeEnter(PixelSets& pixels) {};
	/// <summary>
	/// Called on the main thread at the begininng of every frame, can be used to change the 'global' state of the mode. 
	/// </summary>
	/// <param name="time_ms">The current timenstamp.</param>
	virtual void onFrameStart(uint64_t time_ms) {}
	/// <summary>
	/// Called on each thread, so it can process its own pixels. to do so iterate the pixels:
	/// <pre>
	/// for (auto pixel = pixels_start ; pixel != pixel_end ; pixel++) {
	///		pixel.color *= 0.99;
	/// }
	/// </pre>
	/// </summary>
	/// <param name="pixels_start">A start iterator to the pixel range for the current thread</param>
	/// <param name="pixel_end">An end iterator to the pixel range for the current thread</param>
	/// <param name="time_ms">The timestamp for the current frame</param>
	virtual void onFrameRange(const thread_pixels& pixels, uint64_t time_ms) = 0;
	/// <summary>
	/// Called on the main thread at the end of every frame, to update the mode's state after pixel processign
	/// </summary>
	/// <param name="time_ms">The timestamp for the current frame</param>
	virtual void onFrameEnd(uint64_t time_ms) {}

	/// <summary>
	/// Called on mode termination.
	/// </summary>
	virtual void onModeExit() {};


private: 
	barrier start_frame;
	barrier frame_ready;

	thread_pixels main_thread_pixels;

	std::deque<std::thread> threads;

	std::atomic<uint64_t> cur_time_ms;
	std::atomic<bool> stop{ false };
	uint32_t thread_count;

};
