#pragma once

#include <stdint.h>
#include <ostream>
#include <cmath>

#pragma pack ( push )
#pragma pack ( 1 )

#undef max
/// <summary>
/// A color, with Red, Green and Blue, at values between 0 and 255. 
/// </summary>
struct RGB_t {
    RGB_t() : r(0), g(0), b(0) {}
    RGB_t(uint8_t r, uint8_t g, uint8_t b) : r(r), g(g), b(b) {}
    RGB_t(uint32_t color) : r((color >> 16) & 0xff), g((color >> 8) & 0xFF), b(color & 0xff) {}

    /// <summary>
    /// Red
    /// </summary>
    uint8_t r;
    /// <summary>
    /// Green
    /// </summary>
    uint8_t g;
    /// <summary>
    /// Blue
    /// </summary>
    uint8_t b;

    /// <summary>
    /// Gets a 32 bit representation of the RGB color
    /// </summary>
    /// <returns>a 32 bit representation of the RGB color</returns>
    uint32_t to_uint32() {
        return (((uint32_t)r) << 16) | (((uint32_t)g) << 8) | b;
    }
};

inline bool operator==(const RGB_t& lhs, const RGB_t& rhs) {
    return lhs.r == rhs.r && lhs.g == rhs.g && lhs.b == rhs.b;
}

inline bool operator<(const RGB_t& lhs, const RGB_t& rhs) {
    return lhs.r < rhs.r && lhs.g < rhs.g && lhs.b < rhs.b;
}

inline bool operator>(const RGB_t& lhs, const RGB_t& rhs) {
    return lhs.r > rhs.r && lhs.g > rhs.g && lhs.b > rhs.b;
}

/// <summary>
/// Describes an RGB color, with an Alpha (opacity channel), all with values between 0 and 255
/// </summary>
struct RGBA_t {
    RGBA_t() : r(0), g(0), b(0), a(0) {}
    RGBA_t(uint8_t r, uint8_t g, uint8_t b, uint8_t a) : r(r), g(g), b(b), a(a) {}
    RGBA_t(uint32_t color) : r((color >> 16) & 0xff), g((color >> 8) & 0xFF), b(color & 0xff), a(color >> 24) {}
    RGBA_t(RGB_t o) : r(o.r), g(o.g), b(o.b), a(255) {}
    uint8_t r, g, b;
    /// <summary>
    /// The opacity of the color, with 0 being completely transperant and 255 being completely opaque
    /// </summary>
    uint8_t a;

    /// <summary>
    /// Gets a 32 bit representation of the RGBA color
    /// </summary>
    /// <returns>a 32 bit representation of the RGBA color</returns>
    uint32_t to_uint32() {
        return (((uint32_t)a) << 24) | (((uint32_t)r) << 16) | (((uint32_t)g) << 8) | b;
    }
};

struct HSL_t {
    float h; // Hue [0, 360)
    float s; // Saturation [0, 1]
    float l; // Lightness [0, 1]

    HSL_t() : h(0), s(0), l(0) {}

    HSL_t(const RGB_t& rgb) {
        float r = rgb.r / 255.0f;
        float g = rgb.g / 255.0f;
        float b = rgb.b / 255.0f;

        float max_val = std::max({ r, g, b });
        float min_val = (std::min)({ r, g, b });
        float delta = max_val - min_val;

        l = (max_val + min_val) / 2.0f;

        if (delta == 0.0f) {
            h = 0.0f;
            s = 0.0f;
        }
        else {
            s = delta / (1.0f - std::abs(2.0f * l - 1.0f));

            if (max_val == r) {
                h = 60.0f * std::fmod((g - b) / delta, 6.0f);
            }
            else if (max_val == g) {
                h = 60.0f * ((b - r) / delta + 2.0f);
            }
            else { // max_val == b
                h = 60.0f * ((r - g) / delta + 4.0f);
            }

            if (h < 0.0f) h += 360.0f;
        }
    }

    RGB_t to_RGB() const {
        float c = (1.0f - std::abs(2.0f * l - 1.0f)) * s;
        float x = c * (1.0f - std::abs(std::fmod(h / 60.0f, 2.0f) - 1.0f));
        float m = l - c / 2.0f;

        float r1, g1, b1;

        if (h < 60.0f) {
            r1 = c; g1 = x; b1 = 0;
        }
        else if (h < 120.0f) {
            r1 = x; g1 = c; b1 = 0;
        }
        else if (h < 180.0f) {
            r1 = 0; g1 = c; b1 = x;
        }
        else if (h < 240.0f) {
            r1 = 0; g1 = x; b1 = c;
        }
        else if (h < 300.0f) {
            r1 = x; g1 = 0; b1 = c;
        }
        else {
            r1 = c; g1 = 0; b1 = x;
        }

        return RGB_t{
            uint8_t((r1 + m) * 255.0f),
            uint8_t((g1 + m) * 255.0f),
            uint8_t((b1 + m) * 255.0f)
        };
    }
};

/// <summary>
/// Describes a location in a 3D cartesian space
/// </summary>
struct XYZ_t {
    double x, y, z;

    XYZ_t operator-() { return { -x, -y, -z }; }
    XYZ_t operator+=(const XYZ_t& o) { x += o.x; y += o.y; z += o.z; return *this; }

    friend inline XYZ_t operator-(const XYZ_t& a, const XYZ_t& b) {
        return XYZ_t{ a.x - b.x, a.y - b.y, a.z - b.z };
    }
    friend inline XYZ_t operator+(const XYZ_t& a, const XYZ_t& b) {
        return XYZ_t{ a.x + b.x, a.y + b.y, a.z + b.z };
    }
    friend inline XYZ_t operator*(const XYZ_t& o, double d) {
        return XYZ_t{ o.x * d, o.y * d, o.z * d };
    }
};

struct int_vec3 {
    int i1, i2, i3;
};


inline RGB_t operator* (RGB_t c, double factor) {
    return RGB_t((uint8_t)((double)c.r * factor), (uint8_t)((double)c.g * factor), (uint8_t)((double)c.b * factor));
}

inline RGB_t& operator*=(RGB_t& c, double factor) {
    c.r = (uint8_t)(((double)c.r) * factor);
    c.g = (uint8_t)(((double)c.g) * factor);
    c.b = (uint8_t)(((double)c.b) * factor);
    return c;
}

#undef max
#undef min

inline RGB_t& operator+=(RGB_t& me, const RGB_t& other) {
    me.r = std::min((uint32_t)me.r + other.r, 255u);
    me.g = std::min((uint32_t)me.g + other.g, 255u);
    me.b = std::min((uint32_t)me.b + other.b, 255u);
    return me;
}

inline RGB_t operator-(const RGB_t& lhs, const RGB_t& rhs) {
    return  {
        (lhs.r > rhs.r) ? uint8_t(lhs.r - rhs.r) : (uint8_t)0,
        (lhs.g > rhs.g) ? uint8_t(lhs.g - rhs.g) : (uint8_t)0,
        (lhs.b > rhs.b) ? uint8_t(lhs.b - rhs.b) : (uint8_t)0,
    };
}


inline std::ostream& operator<<(std::ostream& o, const XYZ_t& xyz) {
    o << "[" << xyz.x << ", " << xyz.y << ", " << xyz.z << "]";
    return o;

}

#pragma pack ( pop )
