#pragma once

#include <stdint.h>
#include <ostream>

#pragma pack ( push )
#pragma pack ( 1 )

#undef max
/// <summary>
/// A color, with Red, Green and Blue, at values between 0 and 255. 
/// </summary>
struct RGB_t {
    RGB_t() : r(0), g(0), b(0) {}
    RGB_t(uint8_t r, uint8_t g, uint8_t b) : r(r), g(g), b(b) {}
    RGB_t(uint32_t color) : r((color >> 16) & 0xff), g((color >> 8) & 0xFF), b(color & 0xff) {}

    /// <summary>
    /// Red
    /// </summary>
    uint8_t r;
    /// <summary>
    /// Green
    /// </summary>
    uint8_t g;
    /// <summary>
    /// Blue
    /// </summary>
    uint8_t b;

    /// <summary>
    /// Gets a 32 bit representation of the RGB color
    /// </summary>
    /// <returns>a 32 bit representation of the RGB color</returns>
    uint32_t to_uint32() {
        return (((uint32_t)r) << 16) | (((uint32_t)g) << 8) | b;
    }
};

inline bool operator==(const RGB_t& lhs, const RGB_t& rhs) {
    return lhs.r == rhs.r && lhs.g == rhs.g && lhs.b == rhs.b;
}

inline bool operator<(const RGB_t& lhs, const RGB_t& rhs) {
    return lhs.r < rhs.r && lhs.g < rhs.g && lhs.b < rhs.b;
}

inline bool operator>(const RGB_t& lhs, const RGB_t& rhs) {
    return lhs.r > rhs.r && lhs.g > rhs.g && lhs.b > rhs.b;
}

/// <summary>
/// Describes an RGB color, with an Alpha (opacity channel), all with values between 0 and 255
/// </summary>
struct RGBA_t {
    RGBA_t() : r(0), g(0), b(0), a(0) {}
    RGBA_t(uint8_t r, uint8_t g, uint8_t b, uint8_t a) : r(r), g(g), b(b), a(a) {}
    RGBA_t(uint32_t color) : r((color >> 16) & 0xff), g((color >> 8) & 0xFF), b(color & 0xff), a(color >> 24) {}
    RGBA_t(RGB_t o) : r(o.r), g(o.g), b(o.b), a(255) {}
    uint8_t r, g, b;
    /// <summary>
    /// The opacity of the color, with 0 being completely transperant and 255 being completely opaque
    /// </summary>
    uint8_t a;

    /// <summary>
    /// Gets a 32 bit representation of the RGBA color
    /// </summary>
    /// <returns>a 32 bit representation of the RGBA color</returns>
    uint32_t to_uint32() {
        return (((uint32_t)a) << 24) | (((uint32_t)r) << 16) | (((uint32_t)g) << 8) | b;
    }
};

/// <summary>
/// Describes a location in a 3D cartesian space
/// </summary>
struct XYZ_t {
    double x, y, z;

    XYZ_t operator-() { return { -x, -y, -z }; }
    XYZ_t operator+=(const XYZ_t& o) { x += o.x; y += o.y; z += o.z; return *this; }

    friend inline XYZ_t operator-(const XYZ_t& a, const XYZ_t& b) {
        return XYZ_t{ a.x - b.x, a.y - b.y, a.z - b.z };
    }
    friend inline XYZ_t operator+(const XYZ_t& a, const XYZ_t& b) {
        return XYZ_t{ a.x + b.x, a.y + b.y, a.z + b.z };
    }
    friend inline XYZ_t operator*(const XYZ_t& o, double d) {
        return XYZ_t{ o.x * d, o.y * d, o.z * d };
    }
};

struct int_vec3 {
    int i1, i2, i3;
};


inline RGB_t operator* (RGB_t c, double factor) {
    return RGB_t((uint8_t)((double)c.r * factor), (uint8_t)((double)c.g * factor), (uint8_t)((double)c.b * factor));
}

inline RGB_t& operator*=(RGB_t& c, double factor) {
    c.r = (uint8_t)(((double)c.r) * factor);
    c.g = (uint8_t)(((double)c.g) * factor);
    c.b = (uint8_t)(((double)c.b) * factor);
    return c;
}

#undef max
#undef min

inline RGB_t& operator+=(RGB_t& me, const RGB_t& other) {
    me.r = std::min((uint32_t)me.r + other.r, 255u);
    me.g = std::min((uint32_t)me.g + other.g, 255u);
    me.b = std::min((uint32_t)me.b + other.b, 255u);
    return me;
}

inline RGB_t operator-(const RGB_t& lhs, const RGB_t& rhs) {
    return  {
        (lhs.r > rhs.r) ? uint8_t(lhs.r - rhs.r) : (uint8_t)0,
        (lhs.g > rhs.g) ? uint8_t(lhs.g - rhs.g) : (uint8_t)0,
        (lhs.b > rhs.b) ? uint8_t(lhs.b - rhs.b) : (uint8_t)0,
    };
}


inline std::ostream& operator<<(std::ostream& o, const XYZ_t& xyz) {
    o << "[" << xyz.x << ", " << xyz.y << ", " << xyz.z << "]";
    return o;

}

#pragma pack ( pop )
