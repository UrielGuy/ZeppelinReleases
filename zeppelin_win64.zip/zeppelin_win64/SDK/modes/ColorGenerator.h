﻿#pragma once
#include <array>

#include "Parameters.h"

/// <summary>
/// Generates color spectrums to be used by modes.
/// </summary>
class ColorGenerator {
public: 
	/// <summary>
	/// Initialize the ColorGenerator
	/// </summary>
	/// <param name="params_controller">A reference to the current PArametersController, so we can 
	/// announce parameter changes.</param>
	ColorGenerator(ParametersController& params_controller);

	/// <summary>
	/// Return a color on for a scale
	/// </summary>
	/// <param name="index"> index of the color to get</param>
	/// <returns>A color</returns>
	RGB_t GetColor(uint32_t index); 
	/// <summary>
	/// Reutrns the amout of steps it take the current color scheme to loop around
	/// </summary>
	/// <returns></returns>
	uint32_t LoopLength();
	/// <summary>
	/// Return the current set of parameters available to control the colors. 
	/// </summary>
	/// <returns>A vector of pointers to the relevant parameters.</returns>
	std::vector<Parameter*> GetParameters();

	Parameter color_mode;


private:
	void UpdateTransitions();

	Parameter moves;
	Parameter channel_offset;
	
	RGB_t solid_col = { 0xff, 0xff, 0xff};
	Parameter solid;

	// Configured Color transitions
	Parameter color_count_param;
	int color_count = 2;
	std::array<Parameter, 16> color_params;
	std::array<RGB_t, 16> colors;

	uint32_t loop_length = 768;
	std::function<RGB_t(uint32_t)> generator = [](uint32_t) {return RGB_t{ 10, 20, 30 }; };
	ParametersController& params_controller;
};
