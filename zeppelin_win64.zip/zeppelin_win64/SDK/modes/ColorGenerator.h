#pragma once
#include <array>

#include "Parameters.h"

/// <summary>
/// Generates color spectrums to be used by modes.
/// </summary>
class ColorGenerator {
public: 
	/// <summary>
	/// Initialize the ColorGenerator
	/// </summary>
	/// <param name="params_controller">A reference to the current PArametersController, so we can 
	/// announce parameter changes.</param>
	ColorGenerator(ParametersController& params_controller);

	/// <summary>
	/// Return a color on for a scale
	/// </summary>
	/// <param name="index"> index of the color to get</param>
	/// <returns>A color</returns>
	RGB_t GetColor(size_t index); 
	/// <summary>
	/// Reutrns the amout of steps it take the current color scheme to loop around
	/// </summary>
	/// <returns></returns>
	size_t LoopLength();
	/// <summary>
	/// Return the current set of parameters available to control the colors. 
	/// </summary>
	/// <returns>A vector of pointers to the relevant parameters.</returns>
	std::vector<Parameter*> GetParameters();

	Parameter color_mode;
	Parameter moves;
	Parameter channel_offset;

	Parameter user_colors = Params::Table("Colors", {
			Params::Color("Color", RGB_t((rand() << 16) | (rand() & 0xFFFFFF))),
		}, true, true, 2).OnChange([&]() {
			colors.clear();
			for (const auto& row : user_colors.as<TableData>()) {
				colors.push_back(row[0].as<RGB_t>());
			}
			loop_length = 256 * colors.size();
	}).Group("${mode}.Color");
	Parameter add_color = Params::Button("Add Color", [&]() { 
		user_colors.table().append_row()[0].setValue(RGB_t(rand() << 16 | rand()));
	}).Group("${mode}.Color");

private:
	void UpdateTransitions();

	
	RGB_t solid_col = { 0xff, 0xff, 0xff};
	Parameter solid;

	// Configured Color transitions
	std::vector<RGB_t> colors;

	size_t loop_length = 768;
	std::function<RGB_t(size_t)> generator = [](size_t) {return RGB_t{ 10, 20, 30 }; };
	ParametersController& params_controller;
};
