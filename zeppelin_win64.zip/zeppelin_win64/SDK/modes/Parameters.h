#pragma once

#include <vector>
#include <string>
#include <map>
#include <functional>
#include "RGB_t.h"
#include "mapbox/variant.hpp"

using namespace mapbox::util;
#undef Bool

/// <summary>
/// Manages the value of runtime, user controlled value that affect the behavior of the program. Parameters
/// are colected from all aspects of the program (modes, extensions and built in) and are then controlled by
/// any UserInterface extension. 
/// Parameters have a data type, which is set using the "setValue" method, other than Command types that are
/// invoked by the "executeCommand" method. 
/// Additionally the can be associated with a certain group, such as "Mode", or "Diagnostics", etc. They can 
/// also be tagged as "NoAdmin", meaning they will be exposed to non admin users on UserInterfaces that
/// support that, such as the WebInterface.
/// Parameters should not be created directly. onstead they should be created by the helper methods in the 
/// Params namespace.
/// </summary>
class Parameter {
public:

	/// <summary>
	/// A delegate executed by a command, taking in a name-value map of the parameters.
	/// </summary>
	using CommandDelegate = std::function<void(const std::map<std::string, std::string>&)>;
	/// <summary>
	/// The actual parameter value type. Some type (such as string) are reused for more than one type.
	/// </summary>
	using Value = variant<int, double, std::string, RGB_t, bool>;
	/// <summary>
	/// A delegate type used to register for callbacks when a parameter is changes
	/// </summary>
	using NotifyDelegate = std::function<void(const Parameter&)>;

	/// <summary>
	/// A list of all of the types of parameters available. 
	/// </summary>
	enum class Type {
		/// <summary>
		/// A label, showing a piece of information to the user
		/// </summary>
		Label,
		/// <summary>
		/// An operation that can be invoked by the user.
		/// </summary>
		Command,
		/// <summary>
		/// A user controlled string value
		/// </summary>
		String,
		/// <summary>
		/// A user controlled integer value
		/// </summary>
		Integer,
		/// <summary>
		/// A user controlled floating point (actually a double) value
		/// </summary>
		Float,
		/// <summary>
		/// A user controlled RGB_t color
		/// </summary>
		Color,
		/// <summary>
		///  A user controlled boolean value
		/// </summary>
		Bool,
		/// <summary>
		/// A user controlled selection of a value out of a list of values. 
		/// </summary>
		Options
	};

	/// <summary>
	/// The dispaly name of the parameter, showed by the UI
	/// </summary>
	std::string name;
	/// <summary>
	/// The dispaly group to associate this parameter with
	/// </summary>
	std::string group;

	/// <summary>
	/// The type of the parameter
	/// </summary>
	Type type;
	/// <summary>
	/// For Integer and Float typed parameters, this is the minimum value (included) that can be set.
	/// </summary>
	double range_min;
	/// <summary>
	/// For Integer and Float typed parameters, this is the maximum value (included) that can be set.
	/// </summary>
	double range_max;
	/// <summary>
	/// The list of values that an Options typed parameter can be set to
	/// </summary>
	std::vector<std::string> options;
	/// <summary>
	/// The delegate that is executed when a Command typed parameter is executed. 
	/// </summary>
	CommandDelegate command_delegate;
	/// <summary>
	/// For a Command type, this is the list of the parameters supported by it. Command parameters can only be strings. 
	/// </summary>
	std::vector<std::string> command_parameters;

	/// <summary>
	/// Specifies if the parameter needs admin access to be available to the user. 
	/// </summary>
	bool requires_admin = true;

	/// <summary>
	/// Get the current value of the parameter
	/// </summary>
	/// <typeparam name="T">Either RGB_t, std::string, int or bool. Needs to match the type of the parameter</typeparam>
	/// <returns>The value of the parameter</returns>
	template<typename T>
	const T& as() const { return value.get<T>(); }

	/// <summary>
	/// Sets the value of the current parameter.
	/// </summary>
	/// <param name="val">The value to set</param>
	/// <param name="force_update">If set to true, an update to the value and the update callback wiil be called
	/// even if the value being set is the same as the existing value.</param>
	void setValue(const Value& val, bool force_update = false);
	/// <summary>
	/// Registers for getting a notification when the parameter's value is changed.
	/// </summary>
	/// <param name="name">The name of the callback, must be unique per registration</param>
	/// <param name="del">The delegate to be invoked when the value changes</param>
	void RegisterForChange(const std::string& name, NotifyDelegate del);
	/// <summary>
	/// Executes a command parameter
	/// </summary>
	/// <param name="parameters">The parameters needed to execute the command. The keys need to match the values of the command_parameters</param>
	void executeCommand(std::map<std::string, std::string> parameters);
	/// <summary>
	/// Return a tring representation of the current value
	/// </summary>
	/// <returns></returns>
	std::string to_string() const;
	/// <summary>
	/// Sets the current value with the correct type from a string representation.
	/// </summary>
	/// <param name="s"></param>
	void from_string(const std::string& s);

	
private:
	Value value;
	std::map<std::string, NotifyDelegate> delegates;
};

/// <summary>
/// Contains helper functions/types for creating parameters. 
/// </summary>
namespace Params {
	/// <summary>
	/// A helper class for creating parameters, don't create externally. 
	/// </summary>
	class ParameterBuilder : public Parameter {
	public:
		/// <summary>
		/// Associate the parameter being built with a specific group, such as "Diagnostics" of "Favorites"
		/// </summary>
		/// <param name="group">The name of the group to associate with</param>
		/// <returns>A reference to self, to allow for more calls</returns>
		ParameterBuilder& Group(const std::string& group);
		/// <summary>
		/// Specifies this parameter doesn't require admin access to control on supporting UserInterfaces
		/// </summary>
		/// <returns>A reference to self, to allow for more calls</returns>
		ParameterBuilder& NoAdmin();
		/// <summary>
		/// Register a callback to be invoked when the value of the parameter changes. 
		/// </summary>
		/// <param name="del">The delegate to be invoked, with the parameter changed as an argument</param>
		/// <returns></returns>
		ParameterBuilder& OnChange(NotifyDelegate del);
		/// <summary>
		/// Register a callback to be invoked when the value of the parameter changes. 
		/// </summary>
		/// <param name="del">The delegate to be invoked. The parameter can be accessed easily as a lambda capture.</param>
		/// <returns></returns>
		ParameterBuilder& OnChange(std::function<void(void)> del);
		/// <summary>
		/// For Options parameter, invoke a callback when a specific value was set
		/// </summary>
		/// <param name="val">The value to check for</param>
		/// <param name="del">The delegate to be invoked </param>
		/// <returns></returns>
		ParameterBuilder& OnSelected(const std::string& val, NotifyDelegate del);
		/// <summary>
		/// For Options parameter, invoke a callback when a specific value was set
		/// </summary>
		/// <param name="val">The value to check for</param>
		/// <param name="callback">The delegate to be invoked </param>
		/// <returns></returns>
		ParameterBuilder& OnSelected(const std::string& val, std::function<void()> callback);
	};

	/// <summary>
	/// Create a "Command" parameter, which is usually a button on the UI
	/// </summary>
	/// <param name="name">The display name for the Parameter</param>
	/// <param name="command">The delegate that will be invoked when the command is executed</param>
	/// <param name="command_params">The list of parameters needed by the command.</param>
	/// <returns></returns>
	ParameterBuilder Button(const std::string& name, const Parameter::CommandDelegate& command, const std::vector<std::string> command_params = {});
	/// <summary>
	/// Create a "Command" parameter, which is usually a button on the UI. The overload doesn't have command parameters
	/// </summary>
	/// <param name="name">The display name for the Parameter</param>
	/// <param name="command">The delegate that will be invoked when the command is executed</param>
	/// <returns></returns>
	ParameterBuilder Button(const std::string& name, const std::function<void(void)>& command);
	/// <summary>
	/// Create a label - this just displays a piece of information and cannot be changed by the user. 
	/// </summary>
	/// <param name="name">The name of the laber</param>
	/// <returns></returns>
	ParameterBuilder Label(const std::string& name = "");
	/// <summary>
	/// Create a parameter with a boolean (true/false) value
	/// </summary>
	/// <param name="name">the name of the parameter</param>
	/// <param name="default_value">the initial value</param>
	/// <returns></returns>
	ParameterBuilder BoolVal(const std::string& name, bool default_value);
	/// <summary>
	/// Creates a parameter allowing the user to pick a color. 
	/// </summary>
	/// <param name="name">The name of the Parameter</param>
	/// <param name="default_value">The initial value</param>
	/// <returns></returns>
	ParameterBuilder Color(const std::string& name, RGB_t default_value);
	/// <summary>
	/// Ceate a parameter with a string value
	/// </summary>
	/// <param name="name">The name of the Parameter</param>
	/// <param name="default_value">The initial value</param>
	/// <returns></returns>
	ParameterBuilder StringVal(const std::string& name, const std::string& default_value);
	/// <summary>
	/// Create a Parameter controlling an integer value
	/// </summary>
	/// <param name="name">The name of the parameter</param>
	/// <param name="default_value">The initial value</param>
	/// <param name="min_val">The minimum value (inclusive) for the Parameter</param>
	/// <param name="max_val">The maximum value (inclusive) for the Parameter</param>
	/// <returns></returns>
	ParameterBuilder IntVal(const std::string& name, int default_value, int min_val, int max_val);
	/// <summary>
	/// Create a Parameter controlling a floating point (double) value
	/// </summary>
	/// <param name="name">The name of the parameter</param>
	/// <param name="default_value">The initial value</param>
	/// <param name="min_val">The minimum value (inclusive) for the Parameter</param>
	/// <param name="max_val">The maximum value (inclusive) for the Parameter</param>
	/// <returns></returns>
	ParameterBuilder FloatVal(const std::string& name, double default_value, double min_val, double max_val);
	/// <summary>
	/// Creates a Parameter for selecting a value out of a list of options. 
	/// </summary>
	/// <param name="name">The name of the parameter</param>
	/// <param name="options">The list of options to selet from. This can be modifed later from the "options" variable</param>
	/// <param name="default_value">The initial value</param>
	/// <returns></returns>
	ParameterBuilder Selection(const std::string& name, const std::vector<std::string>& options, const std::string& default_value);
}

/// <summary>
/// This interface is used to notify the main program that the parameters has changed (different set of parameters are relevant, options for a 
/// Options parameter, etc.) and that we should refresh them. 
/// </summary>
class ParametersController {
public:
	/// <summary>
	/// Notify onparameters change and refresh all parameters throughout the program.
	/// </summary>
	virtual void RefreshParameters() = 0;
};