#pragma once

#include <string>
#include <vector>
#include <map>
#include <memory>
#include <libmodes/Parameters.h>

template<typename K, typename V>
class vector_map : public std::vector<std::pair<K, V>> {
public:
	bool contains(const K& needle) const {
		return std::find_if(this->begin(), this->end(), [&](const auto& item) {return item.first == needle; }) != this->end();
	}

	const V& at(const K& needle) const {
		return std::find_if(this->begin(), this->end(), [&](const auto& item) {return item.first == needle; })->second;
	}

	V& operator[] (const K& needle) {
		auto found = std::find_if(this->begin(), this->end(), [&](const auto& item) {return item.first == needle; });
		if (found != this->end()) {
			return found->second;
		}
		else {
			return this->emplace_back(
				std::piecewise_construct,
				std::forward_as_tuple(needle),
				std::forward_as_tuple()).second;
		}

	}
};

/// <summary>
/// This describes a node in the Parameter tree - starting with a root and contaiing groups of parameters. 
/// </summary>
struct ParametersNode {
	/// <summary>
	///  Thename of the current node
	/// </summary>
	std::string name;
	/// <summary>
	/// A vector with all of the parameters in the current node
	/// </summary>
	std::vector<Parameter*> params;
	/// <summary>
	/// A map with the name as the key and the parameters 
	/// </summary>
	vector_map<std::string, std::shared_ptr<ParametersNode>> sub_nodes;
	bool parameters_before_sub_nodes = true;
	ParametersNode& operator[](const std::string& name);

	Parameter* FromPath(const std::string& path) const {
		auto search = path.substr(0, path.find_last_of('['));
		auto found_param = std::find_if(params.begin(), params.end(), [&](const Parameter* item) {return item->name == search; });
		if (found_param != params.end()) {
			if ((*found_param)->type == Parameter::Type::Table && search != path) {
				int x, y;
				sscanf(path.c_str() + search.length(), "[%d,%d]", &x, &y);
				return &(*found_param)->table().cell(y, x);
			}
			return *found_param;
		}

		auto dot = path.find_first_of('.');
		if (dot == std::string::npos) return nullptr;
		auto group = path.substr(0, dot);
		if (!sub_nodes.contains(group)) return nullptr;
		return sub_nodes.at(group)->FromPath(path.substr(dot + 1));
	}
};

