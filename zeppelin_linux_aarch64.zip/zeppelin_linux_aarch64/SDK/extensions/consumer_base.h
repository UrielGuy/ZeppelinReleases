#pragma once

#include <atomic>
#include <thread>
#include <condition_variable>
#include <mutex>
#include <map>
#include <chrono> 

#include "logger.h"
#include "Interfaces.h"

template<typename CLIENT, size_t MAX_CLIENTS>
class ConsumerBase : public FrameConsumer {
public:
	ConsumerBase(const Scene& scene) {
		log.info("Creating consumer");
		threads.fill(nullptr);
		for (const auto& zone_div: scene.zone_divisions) 
			for (const auto& zone : zone_div.second.zones) 
				for (const auto& pixel : zone.pixels) {
					// Paranthesis to prevent macro expension of max
					controllers_length[pixel.controller] = (std::max)((int)controllers_length[pixel.controller], ((int)pixel.index + 1));
		}
		for (const auto& cont_data : controllers_length) {
			threads[cont_data.first] = new std::thread([this, cont_data]() { thread_work(cont_data.first); });
			activated.push_back(cont_data.first);
		}

	}

	~ConsumerBase() {
		log.info("Destroying consumer");
		stop = true;
		frame_ready.notify_all();
		for (auto* thread : threads) {
			if (thread) thread->join();
		}
		log.info("Consumer destroyed. Goodby!");
	}

	void onZonesChanged(const ZoneDivision& zones) override {}
	void onFrame(const ZoneDivision& zones, uint64_t timestamp) override {
		log.trace("Got frame for timestamp {}", timestamp);
		auto start = std::chrono::system_clock::now();
		// This creates a copy of the current zones so we can process this in the other threads. 
		active_zone = zones;
		last_timestamp = timestamp;
		frame_ready.notify_all();

	}

	std::vector<Parameter*> GetConsumerParameters() override {
		return {&brightness, &label1, &label2};
	}

private:

	void thread_work(unsigned id) {
		using namespace std::string_literals;
		std::string name = "controller_id_"s + std::to_string(id);

		log.debug("Starting thread for controller {}", id);

		CLIENT client(id, controllers_length[id]);
		std::unique_lock<std::mutex> lock(ready_mutex);
		double brightness = this->brightness.as<double>();
		while (true) {
			frame_ready.wait(lock);
			if (stop) {
				log.debug("Stopping thread for controller {}", id);
				break;
			}

			uint64_t timestamp = last_timestamp;
			for (const auto& zone : active_zone.zones) for (const pixel& p : zone.pixels) {
				if (p.controller != id) continue;
				client.SetPixelColor(p.strip, p.index, p.color * brightness);
			}

			client.ShowFrame(timestamp);

		}
		log.debug("Exiting thread for controller {}", id);
	}
	Parameter label1 = Params::Label("CopyData").Group("Diagnostics");
	Parameter label2 = Params::Label("SendFrame").Group("Diagnostics");
	Parameter brightness = Params::FloatVal("Brightness", 1, 0, 1).Group("LEDs Renderer");

	std::array<std::thread*, MAX_CLIENTS> threads;
	std::map<int, int> controllers_length;

	ZoneDivision active_zone;
	std::condition_variable frame_ready;
	std::mutex ready_mutex;
	std::atomic<bool> stop{ false };
	std::atomic<uint64_t> last_timestamp; 
	std::vector<uint16_t> activated;

};
