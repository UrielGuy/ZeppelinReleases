#pragma once

#ifdef _WIN32
#include <winsock2.h>
#else
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <arpa/inet.h>
#include <unistd.h>
#endif
#include <stdexcept>
#include <string>
#include <vector>
#include <algorithm>
#include <cstring>
#include <iostream>

#include "udp_listener.h"
#include "logger.h"

#ifndef SOCKET_ERROR
#define SOCKET_ERROR (-1)
#endif
class NetworkClientBase {
protected:
    NetworkClientBase(uint16_t id, uint32_t& clients_count, uint32_t initial_message_buffer_size, uint16_t listener_port, uint16_t tcp_port, controller_type type) :
                    id(id), client_count(clients_count), listener_port(listener_port), tcp_port(tcp_port), type(type){
        
        log.info("Creating controller network client for type {} id {}", type, id);
        
        data_buffer.resize(initial_message_buffer_size);
#ifdef _WIN32
        WSADATA wsaData;
        int iResult = WSAStartup(MAKEWORD(2, 2), &wsaData);
        if (iResult != NO_ERROR) {
            log.critical("WSAStartup failed with error {}", iResult);
            exit(1);
        }
#else
#endif
        listener().RegisterForClientNotifications(
            id,
            [this](uint8_t id, ControllerState state, uint32_t ip) { StatusChange(id, state, ip); }
        );
        client_count++;
    }

    virtual ~NetworkClientBase() {
        log.info("Destroying controller network client for type {} id {}", type, id);
        if (--client_count == 0) {
            log.info("No more clients of type {}, stopping the listener", type);
            listener().stop();
        }

#ifdef _WIN32
        closesocket(fd);
#else
        close(fd);
#endif

#ifdef _WIN32
        WSACleanup();
#endif
        log.info("Destroyed controller network client for type {} id {}", type, id);
    }

    uint16_t Id() { return id; }
    

    void AddMessage(void* data, uint16_t len) {
        last_count = (uint16_t*)(data_buffer.data() + data_offset);
        *last_count = len;
        data_offset += sizeof(len);
        memcpy(data_buffer.data() + data_offset, data, len);
        data_offset += len;
    }

    void AppendDataToLastMessage(void* data, uint16_t len) {
        *last_count += len;
        memcpy(data_buffer.data() + data_offset, data, len);
        data_offset += len;

    }
	
    void FlushMessages() {
        log.trace("Sending {} bytes to controller {} [{}]", data_offset, type, id);
        unsigned sent = 0;
        const char* data = (const char*)data_buffer.data();
        while (sent < data_offset) {
#ifndef _WIN32
            auto res = write(fd, data_buffer.data(), data_offset);
#else
            auto res = send(fd, data + sent, data_offset - sent, 0);
#endif
            if (res == SOCKET_ERROR) {
                log.info("Failed sending to controller {} [{}]. Notifying as down.", type, id);
#ifdef _WIN32
                closesocket(fd);
#else
                close(fd);
#endif
                listener().NotifyDown(id);
                has_ip = false;
                break;
            }
            else {
                sent += res;
            }
        }
        data_offset = 0;

    }

    void BroadcastMessage(uint8_t* data, size_t size) {
        log.debug("Broadcasting a message to all controllers of type {} on port {}", type, tcp_port);
        // Broadcast RESET over UDP to all clients.
        auto sock = socket(AF_INET, SOCK_DGRAM, 0);
        if (sock < 0) {
            log.error("Failed creating broadcast socket!");
            return;
        }


        int broadcastEnable = 1;
        int ret = setsockopt(sock, SOL_SOCKET, SO_BROADCAST, (const char*)&broadcastEnable, sizeof(broadcastEnable));
        if (ret < 0) {
            log.error("Failed setting socket to broadcast!");
#ifdef _WIN32
            closesocket(sock);
#else
            close(sock);
#endif
            return;
        }

        struct sockaddr_in s;
        memset(&s, '\0', sizeof(struct sockaddr_in));
        s.sin_family = AF_INET;
        s.sin_port = htons(tcp_port);
        s.sin_addr.s_addr = htonl(INADDR_BROADCAST);

        ret = sendto(sock,(const char*) data, (int)size, 0, (struct sockaddr*)&s, sizeof(struct sockaddr_in));
        if (ret < 0) {
            log.error("Failed to send broadcast ");
        }

#ifdef _WIN32
        closesocket(sock);
#else
        close(sock);
#endif
    }

    bool is_connected() {
        return has_ip;
    }

private:

    void StatusChange(uint8_t id, ControllerState new_state, uint32_t ip) {
        log.info("Controller {} [{}] was notified as {} with ip {}", type, id, new_state, ip_to_str(ip));
        switch (new_state) {
        case ControllerState::Online:
            Connect(ip);
        }
    }

    bool Connect(uint32_t addr) {
        log.info("Controller {} [{}] is trying to connect to IP {}", type, id, ip_to_str(addr));
#ifdef _WIN32
        fd = socket(AF_INET, SOCK_STREAM, 0);
#else
        fd = socket(AF_INET, SOCK_STREAM, 0);
#endif
        if (fd < 0) {
            log.error("Failed creating socket for controller {} [{}]", type, id);
            listener().NotifyDown(id);
            return false;
        }

        int flag = 1;
        if (setsockopt(fd, IPPROTO_TCP, TCP_NODELAY, (char*)&flag, sizeof(flag))) {
            log.warn("Failed setting TCP_NODELAY for controller {} [{}]", type, id);
        }

        memset(&address, 0, sizeof(address));
        address.sin_family = AF_INET;
        address.sin_addr.s_addr = addr;
        address.sin_port = htons(tcp_port);

        if (connect(fd, (sockaddr*)&address, sizeof(address)) != 0) {
            log.warn("Failed connecting to controller {} [{}] with IP {}", type, id, ip_to_str(addr));
            listener().NotifyDown(id);
            return false;
        }
        else
        {
            log.info("Connected to controller {} [{}] with IP {}", type, id, ip_to_str(addr));
        }

        has_ip = true;
        return true;

    }

    uint32_t& client_count;

    Listener& listener() {
        static Listener instance(listener_port, type);
        return instance;
    }

    uint16_t id;

    uint16_t* last_count = nullptr;

#ifdef _WIN32
    SOCKET fd = INVALID_SOCKET;
#else
    int fd;
#endif
    sockaddr_in address;
    bool has_ip = false;
    std::vector<uint8_t> data_buffer;
    uint32_t data_offset = 0;

    uint16_t listener_port;
    uint16_t tcp_port;
    controller_type type;


};