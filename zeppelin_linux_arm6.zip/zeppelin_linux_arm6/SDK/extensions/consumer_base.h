#pragma once

#include <atomic>
#include <thread>
#include <condition_variable>
#include <mutex>
#include <map>
#include <chrono> 

#include "logger.h"
#include "Interfaces.h"

template<typename CLIENT, size_t MAX_CLIENTS>
class ConsumerBase : public FrameConsumer {
public:
	ConsumerBase(std::vector<int> controllers) {
		log.info("Creating consumer");
		std::fill(this->controllers.begin(), this->controllers.end(), controllers.empty());
		for (int c : controllers) {
			this->controllers[c] = true;
		}
		threads.fill({ nullptr, nullptr });


	}

	~ConsumerBase() {
		log.info("Destroying consumer");
		stop = true;
		frame_ready.notify_all();
		for (const auto& thread : threads) {
			if (thread.first) thread.first->join();
		}
		log.info("Consumer destroyed. Goodby!");
	}

	void onZonesChanged(const multispan<pixel>& pixels) override {
		std::map<int, int> new_controllers_length;
		size_t total_pixles = pixels.size();
		for (const auto& pixel : pixels) {
			if (!controllers[pixel.connection.controller]) continue;
			// Paranthesis to prevent macro expension of max
			new_controllers_length[pixel.connection.controller] = (std::max)((int)new_controllers_length[pixel.connection.controller], ((int)pixel.connection.index + 1));
		}

		for (const auto& cont_data : new_controllers_length) {
			if (cont_data.first > 127 || cont_data.second == controllers_length[cont_data.first]) continue;
			controllers_length[cont_data.first] = cont_data.second;
			if (threads[cont_data.first].first) {
				if (threads[cont_data.first].second) {
					threads[cont_data.first].second->SetLength(cont_data.second);
				}
			}
			else {
				threads[cont_data.first].first = new std::thread([this, cont_data]() { thread_work(cont_data.first); });
			}
		}

		pixels_copy.resize(total_pixles);
	}

	void OnModeChange(const std::string& zone_name) final {}

	void onFrame(uint64_t timestamp, const multispan<pixel>& pixels, std::vector<std::map<std::string, extra_shape>*> mode_elements) override {
		log.debug("Got frame for timestamp {}", timestamp);
		auto start = std::chrono::system_clock::now();
		// This creates a copy of the current zones so we can process this in the other threads. 
		size_t total_size = pixels.size();
		size_t index = 0;
		// Slightly optimize the copy by not going through multispan.
		for (const auto& item : pixels.data) {
			std::copy(item.begin(), item.end(), pixels_copy.begin() + index);
			index += item.size();
		}
		last_timestamp = timestamp;
		frame_ready.notify_all();

	}

	std::vector<Parameter*> GetConsumerParameters() override {
		return {&brightness, &label1, &label2};
	}

private:

	void thread_work(unsigned id) {
		using namespace std::string_literals;
		std::string name = "controller_id_"s + std::to_string(id);

		log.debug("Starting thread for controller {}", id);

		CLIENT client(id, controllers_length[id]);
		threads[id].second = &client;
		std::unique_lock<std::mutex> lock(ready_mutex);
		double brightness = this->brightness.as<double>();
		while (true) {
			frame_ready.wait(lock);
			if (stop) {
				log.debug("Stopping thread for controller {}", id);
				break;
			}
			uint64_t timestamp = last_timestamp;
			for (const pixel& p : pixels_copy) {
				if (p.connection.controller != id) continue;
				client.SetPixelColor(p.connection.strip, p.connection.index, p.color * brightness);
			}

			client.ShowFrame(timestamp);

		}
		log.debug("Exiting thread for controller {}", id);
	}
	Parameter label1 = Params::Label("CopyData").Group("Diagnostics");
	Parameter label2 = Params::Label("SendFrame").Group("Diagnostics");
	Parameter brightness = Params::FloatVal("Brightness", 1, 0, 1).Group("LEDs Renderer");

	std::array<std::pair<std::thread*, CLIENT*>, MAX_CLIENTS> threads;
	std::map<int, int> controllers_length;

	std::vector<pixel> pixels_copy;
	std::condition_variable frame_ready;
	std::mutex ready_mutex;
	std::atomic<bool> stop{ false };
	std::atomic<uint64_t> last_timestamp; 

	std::array<bool, 0x10000> controllers;


};
