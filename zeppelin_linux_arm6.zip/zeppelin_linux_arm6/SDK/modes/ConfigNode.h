#pragma once

#include <string>
#include <vector>
#include "RGB_t.h"
/// <summary>
/// Represents a node of the persistent configuration saves next to each YAML config file.
/// Modes/extensions can use this to save user settings, calibrations, etc.
/// 
/// Every node can be one of 3 types - 
/// <list>
/// <li> A value - a string containing a value saved by the user</li>
/// <li> A list - a container for other ConfigNodes accessed by an zero based index</li>
/// <li> A map - a container for other ConfigNodes accessed by a string name</li>
/// </summary>
class ConfigNode {
public:
	/// <summary>
	/// Sentinal type, allowing to add an empty node by calling <pre>node[ConfigNode::Append]</pre>
	/// </summary>
	struct AppendType {} Append;

	/// <summary>
	/// Clears the node, removeing all values, children and items.
	/// </summary>
	virtual void clear() = 0;
	/// <summary>
	/// Make this node into a value node, containng the specified value.
	/// If this is already a list or a map, throw an exception
	/// </summary>
	/// <param name="value">The value to set</param>
	/// <returns>a reference to the value that was just set</returns>
	virtual const std::string& operator=(const std::string& value) = 0;
	/// <summary>
	/// Read the current value as a string. Throws an exception if not a value
	/// </summary>
	virtual operator std::string& () = 0;
	/// <summary>
	/// Read the current value as a string. Throws an exception if not a value
	/// </summary>
	virtual operator const std::string& () const = 0;
	/// <summary>
	/// Access a sub element if this is a list.
	/// </summary>
	/// <param name="index">The index to the sub element, resize the list if needed</param>
	/// <returns>A reference to the proper sub element</returns>
	virtual ConfigNode& operator[](int index) = 0;
	/// <summary>
	/// Add a single empty element to the current list, and return a reference to it. 
	/// </summary>
	/// <param name="">Use ConfigNode::Append</param>
	/// <returns>A reference to the newly created element</returns>
	virtual ConfigNode& operator[](AppendType) = 0;
	/// <summary>
	/// If this node is a list, returns its size. otherwise throws an exception
	/// </summary>
	/// <returns>The size of the current list element</returns>
	virtual size_t size() = 0;
	/// <summary>
	/// Removes an item from the list in the current item at the specified index. 
	/// Throws an exception if it's not a list. 
	/// </summary>
	/// <param name="index">The index of the item to remove</param>
	virtual void RemoveItem(int index) = 0;
	/// <summary>
	/// Access an child element in the current map element. Creates the child element if it doesnt exists. 
	/// Throws an exception if the current element is not a map. 
	/// </summary>
	/// <param name="child">The name of the element to find or create.</param>
	/// <returns>A reference to the child element named 'child'</returns>
	virtual ConfigNode& operator[](const std::string& child) = 0;
	/// <summary>
	/// Return a list of all of the childeren in the current map element.
	/// Throw an exception if not a map.
	/// </summary>
	/// <returns></returns>
	virtual std::vector<std::string> Children() const = 0;
	/// <summary>
	/// Return true if the current map element contains a child names 'child'. 
	/// Throws an exepction if this is not a map.
	/// </summary>
	/// <param name="child"></param>
	/// <returns></returns>
	virtual bool Has(const std::string& child) = 0; 
	/// <summary>
	/// Removes a child named 'child' from the current map. 
	/// Throws an exepction if this is not a map.
	/// </summary>
	/// <param name="child"></param>
	virtual void RemoveChild(const std::string& child) = 0;
	/// <summary>
	/// Set a default value if doesn't exist.
	/// </summary>
	virtual std::string Default(const std::string& value) = 0;

	template<typename T>
	void operator=(const T& other) { *this = std::to_string(other); }

	void operator=(const char* other) { *this = std::string(other); }

	void operator=(XYZ_t& other) { (*this)[0] = other.x; (*this)[1] = other.y; (*this)[2] = other.z; }

	template<typename T>
	T as() = delete;
};

template <>	inline double ConfigNode::as<double>() { return std::stod(*this); }
template <>	inline int ConfigNode::as<int>() { return std::stoi(*this); }
template <>	inline XYZ_t ConfigNode::as<XYZ_t>() { return XYZ_t(std::stof((*this)[0]), std::stof((*this)[1]), std::stof((*this)[2])); }
template <>	inline std::string ConfigNode::as<std::string>() { return (std::string)*this; }
template <>	inline bool ConfigNode::as<bool>() { auto str = (std::string)*this; return str == "1" || str == "True" || str == "true" || str == "TRUE" || str == "yes" || str == "Yes" || str == "YES"; }
