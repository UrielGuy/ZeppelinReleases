#pragma once

#include <string>
#include <vector>
#include "Zone.h"
#include "Parameters.h"
#include "ConfigNode.h"

/// <summary>
/// Defines a 'Mode' - a piece of code capable of setting the color of each pixel at advancing timepoints. 
/// </summary>
class Mode {
public:
	/// <summary>
	/// The name of the mode. If RTTI is available, it defualts to the name of the class. 
	/// </summary>
	/// <returns>A string with the display name of the mode</returns>
	virtual std::string name() const;
	/// <summary>
	/// A virtual destructor, does nothing in this base class
	/// </summary>
	virtual ~Mode() {}
	/// <summary>
	/// Called when the mode is initialized, with the current scene and zone that the mode will have to render. 
	/// </summary>
	/// <param name="scene">The whole scene that is being rendered, used for all parameters needed other than the pixels</param>
	/// <param name="zone">The zone rendered by this mode, where the actual pixels come from.</param>
	virtual void onEnter(Zone& zone) {}
	/// <summary>
	/// Called when the mode is being destroyed
	/// </summary>
	virtual void onExit() {}
	/// <summary>
	/// Called for each frame. This function should change the color of the pixels in the Zone to set them.
	/// </summary>
	/// <param name="zone">The zone being rendered</param>
	/// <param name="time_ms">The timestamp, in ms, to which the frame corresponds.</param>
	virtual void onFrame(Zone& zone, uint32_t time_ms) {}

	/// <summary>
	/// Get a vector of pointers to the parameters this mode exposes to modify its behavior. 
	/// It is recommended to make the parameters members, and return their address. If not
	/// otherwise set, parameters added here will join the "Mode" parameters group. 
	/// </summary>
	/// <returns>A vector of parameters poointers to the current mode's parametrs.</returns>
	virtual std::vector<Parameter*> GetModeParameters() = 0;

protected: 
	/// <summary>
	/// Return a color on the full saturation "Rainbow" spectrum. 
	/// It rotates back to the zero position every 768 indexes
	/// </summary>
	/// <param name="index"></param>
	/// <returns></returns>
	RGB_t colorwheel(uint32_t index) const;
};

#ifdef WIN32
#define FUNCTION_EXPORT extern "C" __declspec(dllexport)
#else
#define FUNCTION_EXPORT extern "C"
#endif

#ifdef _MSC_VER
#define FUNCTION_CALL __cdecl
#else
#define FUNCTION_CALL
#endif
