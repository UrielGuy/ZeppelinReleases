#pragma once

#include <cmath>
#include <vector>
#include <map>
#include <unordered_map>
#include <algorithm>
#include "mapbox/variant.hpp"
#include "RGB_t.h"

/// <summary>
/// This structs describes the phyhsical connection of pixel to a controller.
/// </summary>
struct physical_loc {
	/// <summary>
	/// The ID of the controller
	/// </summary>
	uint8_t controller = -1;
	/// <summary>
	/// The strip number for the pixel
	/// </summary>
	uint8_t strip = -1;
	/// <summary>
	/// The index of the pixel on the strip
	/// </summary>
	uint16_t pixel = 0;
};


/// <summary>
/// A representetion of a single pixel in a scene. 
/// </summary>
struct pixel {
	/// <summary>
	/// Create a pixel in to be added to a scene
	/// </summary>
	/// <param name="pl">How the pixel is wired to the system</param>
	/// <param name="loc">TYhe location of the pixel in a cartesian 3D space, in millimeters</param>
	/// <param name="color"></param>
	pixel(physical_loc pl, XYZ_t loc, RGB_t color = RGB_t(0,0,0)) : 
		controller(pl.controller), strip(pl.strip), index(pl.pixel), x((float)loc.x), y((float)loc.y), z((float)loc.z), color(color) {
		x_angle = atan2(z, y);
		y_angle = atan2(z, x);
		z_angle = atan2(y, x);
	}
	/// <summary>
	/// The ID of the controller for the pixel
	/// </summary>
	uint8_t controller;
	/// <summary>
	/// The strip number in the controller for the pixel
	/// </summary>
	uint8_t strip;
	/// <summary>
	/// The index of the pixel in its strip
	/// </summary>
	uint16_t index;

	/// <summary>
	/// The pixel's X coordinates in a millimeter based cartesian coordinates system
	/// </summary>
	float x;
	/// <summary>
	/// The pixel's Y coordinates in a millimeter based cartesian coordinates system
	/// </summary>
	float y;
	/// <summary>
	/// The pixel's Z coordinates in a millimeter based cartesian coordinates system
	/// </summary>
	float z;
	/// <summary>
	/// when looking at the model from left to right of the epoch, what is the angle of the pixel in degrees
	/// </summary>
	float x_angle;
	/// <summary>
	/// when looking at the model from front to back of the epoch, what is the angle of the pixel in degrees
	/// </summary>
	float y_angle;
	/// <summary>
	/// when looking at the model from top to bottom of the epoch, what is the angle of the pixel in degrees
	/// </summary>
	float z_angle;
	/// <summary>
	/// What is the color of the current pixel? Set this in a mode to change the display
	/// </summary>
	RGB_t color;
	/// <summary>
	/// The pixel's location as an XYZ_t
	/// </summary>
	/// <returns></returns>
	XYZ_t location() const { return { x,y,z }; }
};


/// <summary>
/// The bounds of a cube
/// </summary>
struct cube_bounds {
	double left, right, top, bottom, front, back;

	/// <summary>
	/// What the largest distance possible between two points in this cube
	/// </summary>
	/// <returns></returns>
	double max_distance();
	/// <summary>
	/// What is the max distance in this cube from the specified point
	/// </summary>
	/// <param name="epoch">Thepoint to measure the distance froem</param>
	/// <returns></returns>
	double max_distance_from(XYZ_t epoch);
	/// <summary>
	/// Is the specified poiont contained within the cube?
	/// </summary>
	/// <param name="point">the point to check</param>
	/// <returns></returns>
	bool contains(XYZ_t point);
};


/// <summary>
/// Descibe a shape that can be drawn when 3D rendering the scene
/// </summary>
struct extra_shape {
	/// <summary>
	/// An external 3d model file, to be loaded and dispalyed
	/// </summary>
	struct extrnal_model {
		/// <summary>
		/// The path to the file to be loaded
		/// </summary>
		std::string path;
		XYZ_t scale{ 1,1,1 };
		/// <summary>
		/// The color in which to draw the model, with an optional transperancy 
		/// </summary>
		RGBA_t color{ 80, 80, 80, 255 };
		/// <summary>
		/// true to draw just the wireframe, false to draw facets
		/// </summary>
		bool wireframe{ false };
	};
	/// <summary>
	/// Describes a cube to be drawn
	/// </summary>
	struct box {
		/// <summary>
		/// Size in mm of the box to draw
		/// </summary>
		XYZ_t size;
		/// <summary>
		/// The color in which to draw the shape, with an optional transperancy 
		/// </summary>
		RGBA_t color;
	};
	struct sphere {
		/// <summary>
		/// Radius in mm if the sphere to draw
		/// </summary>
		double size;
		/// <summary>
		/// The color in which to draw the shape, with an optional transperancy 
		/// </summary>
		RGBA_t color;
	};
	struct cylinder {
		/// <summary>
		/// The height of the cylinder to be drawn in mm
		/// </summary>
		double height;
		/// <summary>
		/// Radius in mm of the cylinder to be drawn
		/// </summary>
		double radius;
		/// <summary>
		/// The color in which to draw the shape, with an optional transperancy 
		/// </summary>
		RGBA_t color;
	};
	/// <summary>
	/// Describes a mesh to be drawn
	/// </summary>
	struct mesh {
		/// <summary>
		/// A list of all of the points in the mesh
		/// </summary>
		std::vector<XYZ_t> points;
		/// <summary>
		/// The paths of the poligons, describes in int3_vec of indexes to the points
		/// </summary>
		std::vector<int_vec3> paths;
		/// <summary>
		/// The color in which to draw the shape, with an optional transperancy 
		/// </summary>
		RGBA_t color;
	};

	/// <summary>
	/// The name of the object
	/// </summary>
	std::string name;
	/// <summary>
	/// The actual shape to be drawn
	/// </summary>
	mapbox::util::variant<extrnal_model, box, sphere, cylinder, mesh> data;
	/// <summary>
	/// The location of the shape. It will be translated according to the XYZ_t value, in mm
	/// </summary>
	XYZ_t location{ 0,0,0 };
	/// <summary>
	/// The rotation of the sahpe. It will be rotated (in order) around X, Y and Z. In degrees.
	/// </summary>
	XYZ_t rotation{ 0,0,0 };
};

struct camera_data {
	std::string name;
	XYZ_t position;
	XYZ_t target;
};

enum class power_calc_mode {
	max_channel_brightness,
	sum_pixel_brightness,
};

struct power_data_t {
	double idle_per_pixel = 0;
	double per_pixel_full = 0;
	power_calc_mode mode;
};

/// <summary>
/// Represents a part of a scene that can be rendered.
/// </summary>
class Zone {
public:
	/// <summary>
	/// The name of the zone
	/// </summary>
	std::string name;
	/// <summary>
	/// The pixels contained within the zone
	/// </summary>
	std::vector<pixel> pixels;
	/// <summary>
	/// The elements to be drawn added by the current mode.
	/// </summary>
	std::map<std::string, extra_shape> mode_elements;
	/// <summary>
	/// Get the cube containnig all the pixels in the current zone. The cube may contains pixels from other zones as well!
	/// </summary>
	/// <returns></returns>
	cube_bounds Bounds() const {
		if (pixels.empty()) return cube_bounds{ 0,0,0,0,0,0 };
		cube_bounds res = { pixels[0].x, pixels[0].x, pixels[0].z, pixels[0].z, pixels[0].y, pixels[0].y };
		for (const auto& p : pixels) {
			res.left = (std::min)((double)res.left, (double)p.x);
			res.right = (std::max)((double)res.right, (double)p.x);
			res.bottom = (std::min)((double)res.bottom, (double)p.z);
			res.top = (std::max)((double)res.top, (double)p.z);
			res.back = (std::min)((double)res.back, (double)p.y);
			res.front = (std::max)((double)res.front, (double)p.y);
		}

		return res;
	}
};

/// <summary>
/// Represents a set of complementing zones.
/// This is a collection of zones,. where every pixel is contained in exacly one zone
/// </summary>
class ZoneDivision {
public:
	/// <summary>
	///  The name of this setup 
	/// </summary>
	std::string name;
	/// <summary>
	/// The list of zones in this devision;
	/// </summary>
	std::vector<Zone> zones;

	/// <summary>
	/// Gets a cube conatining all the pixels in all the zones in this division.
	/// </summary>
	/// <returns></returns>
	cube_bounds Bounds() const {
		cube_bounds res = zones.begin()->Bounds();
		for (const auto& item : zones) {
			auto other = item.Bounds();
			res.left = (std::min)(res.left, other.left);
			res.right = (std::max)(res.right, other.right);
			res.bottom = (std::min)(res.bottom, other.bottom);
			res.top = (std::max)(res.top, other.top);
			res.back = (std::min)(res.back, other.back);
			res.front = (std::max)(res.front, other.front);
		}
		return res;
	}

};

/// <summary>
/// This is the object defining the base of what we can calculate and dispaly. It is the root of the state of the program
/// </summary>
class Scene {
public: 
	/// <summary>
	/// The name of the current scene
	/// </summary>
	std::string name;
	/// <summary>
	/// The path to the configuration file defining this scene
	/// </summary>
	std::string path;
	/// <summary>
	/// The path , relative to the config file or absolute, of where the static web files reside
	/// </summary>
	std::string web_root = "web/";
	/// <summary>
	/// The TCP port the web server should listen on
	/// </summary>
	uint16_t web_port = 0;
	/// <summary>
	/// The path , relative to the config file or absolute, of where the videos for the Video mode reside
	/// </summary>
	std::string videos_dir = "videos/";
	/// <summary>
	/// A list of all of the zone divisions supported by this configuration
	/// </summary>
	std::map<std::string, ZoneDivision> zone_divisions;
	/// <summary>
	/// A list of extra elements to be rendered.
	/// </summary>
	std::map<std::string, extra_shape> configured_elements;

	/// <summary>
	/// Configuration on how to calculate the estimated power consumption
	/// </summary>
	power_data_t power_data;

	/// <summary>
	/// A list of cameras available for the 3d renderer
	/// </summary>
	std::vector<camera_data> cameras;

	/// <summary>
	/// A list of logins for UserInterfaces to check if a user is an admin
	/// </summary>
	std::unordered_map<std::string, std::string> admin_logins;

	/// <summary>
	/// A list of modes available for the scene
	/// </summary>
	std::vector<std::string> modes;

	/// <summary>
	/// The extensions to be loaded with this scene
	/// </summary>
	std::vector<std::string> extensions;

	/// <summary>
	/// Get a cube returning all possible pixels in the scene.
	/// </summary>
	/// <returns></returns>
	cube_bounds Bounds() const{
		cube_bounds res = zone_divisions.begin()->second.Bounds();
		for (const auto& item : zone_divisions) {
			auto other = item.second.Bounds();
			res.left = (std::min)(res.left, other.left);
			res.right = (std::max)(res.right, other.right);
			res.bottom = (std::min)(res.bottom, other.bottom);
			res.top = (std::max)(res.top, other.top);
			res.back = (std::min)(res.back, other.back);
			res.front = (std::max)(res.front, other.front);
		}
		return res;
	}

};


